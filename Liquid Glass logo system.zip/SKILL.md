---
name: hymui-design
description: Use this skill to generate well-branded interfaces and assets for Hymui, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key files: `readme.md` (foundations + content rules), `styles.css` → `tokens/` (all design tokens; dark default, `data-theme="light"`, `data-transparency="reduced"`, `data-motion="reduced"`, `data-contrast="high"`), `components/` (Hm* primitives with .d.ts + .prompt.md), `guidelines/component-specs.md` (product component APIs for Vue), `ui_kits/hymui/` (7 example screens), `assets/` (logo marks — never redraw).
