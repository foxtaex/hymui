# Hymui Design System

Hymui is a **local-first, federated project-planning platform** where people and AI agents plan and build together. It supports general projects — not only software — combining Projects, Boards, Docs, Planner, Whiteboards, AI Agents, Settings, plugins, repository links, and decentralized collaboration.

The visual language is **Hymui Liquid Glass**: responsive layers of polished glass floating above solid, readable project content. Inspired by Apple's material refinement, but an original Hymui system — modular corner forms, central-dot details, mint active light.

## Sources
- Hymui logo system: `uploads/Hymui Logo System Design/Hymui Logo System.dc.html` (four-module mark, wordmark rules, palette)
- Liquid Glass design direction: `Hymui Liquid Glass.dc.html` (material anatomy, four glass levels, motion, accessibility contract)
- Product brief: pasted UI-kit specification (chat, 2026-07). No Figma or production codebase was provided.

## Content fundamentals
- **Tone**: calm, precise, friendly-professional. Short sentences. No exclamation marks, no hype.
- **Casing**: sentence case everywhere — buttons ("Review diff", "Approve"), titles, menus. The wordmark is always lowercase: `hymui.` (terminal period included, accent-colored dot).
- **Voice**: second person for the user ("Your instance is healthy"), named agents in third person ("Scout will merge 12 duplicate tasks").
- **Agent copy**: proposals state exactly what will change and where: "Scout will merge 12 duplicate tasks across 3 boards. This edits shared project data." Approval verbs are explicit: Approve / Review diff / Reject.
- **Metadata**: uppercase IBM Plex Mono micro-labels with 0.08–0.16em tracking: `AGENT RUNNING`, `PLANNED · 3`, `BLUR 26 · α 0.44`.
- **Emoji**: never. Unicode glyphs only as functional symbols (✓, ▾, ⌘).
- Never placeholder titles like "Hello World" — always plausible project content (federation, CRDT sync, agent runs, releases).

## Visual foundations
- **Color**: dark-first. Grounds #0D1211 / #141A19; warm light ground #EFEBE3. Active light is the mint→green gradient (#0FBFAE→#12A05F). #6FBFAF tints glass and marks calm states; #2C6A61 draws outlines in light mode. Semantic status colors are oklch-derived to match brand chroma.
- **Type**: Quicksand (400–700) for all UI; IBM Plex Mono (400–600) for code, metadata, tokens, shortcuts. Display 44/600/−0.028em → metadata 11 mono uppercase.
- **Glass material**: backdrop blur + saturation, brand tint gradient, 1px translucent border, inset top edge-light, restrained shadow, optional pointer-tracked specular sheen. Four levels: Bar (blur 22/α .30) → Panel (26/.44) → Overlay (32/.62) → Focus (36/.88).
- **Content stays solid**: editors, long-form reading, dense cards, forms, tables, code on `--color-surface-solid`. Glass frames; it never sits behind paragraphs.
- **Identity details**: modular corner form (rounded L, echoing one logo module) on panels/dialogs; 4–5px central dots as separators between connected controls; connected controls share one glass surface and separate fluidly when active.
- **Radii**: 6→26px scale; controls 14px, bars/popovers 22px, panels/dialogs 26px. Never fully square.
- **Shadows**: soft black, 4 levels + accent glow for primary actions; always paired with edge-light, never alone.
- **Motion**: spring `cubic-bezier(0.34,1.3,0.4,1)` 160–420ms. Controls expand from their trigger; depth changes animate blur+shadow+scale together — never bare opacity fades. Reduced motion collapses all durations to 0.
- **Hover**: background lightens (rgba text-color at 6–8%); press scales to 0.98; active nav items take the accent gradient with dark-on-mint text.
- **Backgrounds**: quiet radial mint/green ambience on stages; never busy gradients under text.

## Iconography
- Brand marks: `assets/hymui-mark-vivid.svg` (teal modules, emerald core), `assets/hymui-mark-mono.svg` and `assets/hymui-mark-line.svg` (currentColor). The line mark doubles as a status glyph (agents, instances, plugins).
- UI icons: **Lucide** (CDN) — 1.5px stroke, round caps, matches the mark's geometry. *Substitution flag: no icon set was provided; Lucide is the closest neutral match. Replace if Hymui ships its own set.*
- No emoji, no filled icon fonts.

## Theme & mode switches (attributes on `<html>`)
- `data-theme="light" | "dark"` (dark is default; "system" = set from `prefers-color-scheme` at boot)
- `data-transparency="reduced"` — near-solid glass, no sheen (also the no-backdrop-filter fallback recipe)
- `data-motion="reduced"` — all durations 0
- `data-contrast="high"` — stronger text/border separation

## Index
- `styles.css` → `tokens/` (colors, typography, spacing, effects, motion, layout, base)
- `assets/` — logo marks
- `guidelines/` — foundation specimen cards
- `components/` — Hm* React primitives (visual reference implementations; production is Vue 3 + SCSS, see prompt.md files for recommended Vue props/events/slots)
- `ui_kits/hymui/` — example screens (Projects, Board, Docs, Planner, Whiteboard, AI review, Settings)
- `SKILL.md` — agent skill entry point

## Intentional additions
- `HmIcon` wrapper for Lucide glyphs (consistent sizing/stroke).

## Caveats
- Production target is Nuxt 4 / Vue 3 / TS / SCSS. Components here are React reference implementations of the same anatomy and tokens; each `.prompt.md` documents the recommended Vue API.
- Fonts are served from Google Fonts (no font binaries provided).
