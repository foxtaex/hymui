import React from "react";
export function HmCombobox({ label, options = [], value, placeholder = "Search or pick…", onChange, style }) {
  const [q, setQ] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const current = options.find(o => o.value === value);
  const filtered = options.filter(o => o.label.toLowerCase().includes(q.toLowerCase()));
  return React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 6, position: "relative", fontFamily: "var(--font-sans)", ...style } },
    label && React.createElement("span", { style: { fontSize: "var(--text-label-size)", fontWeight: 600 } }, label),
    React.createElement("input", { role: "combobox", "aria-expanded": open, placeholder,
      value: open ? q : (current ? current.label : ""),
      onFocus: () => { setOpen(true); setQ(""); }, onBlur: () => setTimeout(() => setOpen(false), 150),
      onChange: e => setQ(e.target.value),
      style: {
        height: "var(--size-control-md)", padding: "0 14px", borderRadius: "var(--radius-md)", width: "100%", boxSizing: "border-box",
        border: `1px solid ${open ? "var(--color-accent)" : "var(--color-border-strong)"}`,
        background: "var(--color-surface-solid)", color: "var(--color-text)", fontFamily: "var(--font-sans)", fontSize: 14, outline: "none"
      } }),
    open && React.createElement("div", { role: "listbox", style: {
  position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0, zIndex: 500,
  padding: 6, borderRadius: "var(--radius-lg)", maxHeight: 240, overflowY: "auto",
  background: "linear-gradient(160deg, var(--color-glass-tint), rgba(13,18,17,var(--glass-alpha-overlay)) 70%)",
  backdropFilter: "blur(var(--glass-blur-overlay)) saturate(var(--glass-saturation))",
  WebkitBackdropFilter: "blur(var(--glass-blur-overlay)) saturate(var(--glass-saturation))",
  border: "1px solid var(--color-glass-border)",
  boxShadow: "var(--edge-highlight), var(--shadow-3)", transformOrigin: "top"
} },
      (filtered.length ? filtered : [{ value: "__none", label: "No matches", disabled: true }]).map(o =>
        React.createElement("div", { key: o.value, role: "option",
          onMouseDown: () => { if (!o.disabled) { onChange && onChange(o.value); setOpen(false); } },
          style: { padding: "9px 12px", borderRadius: "var(--radius-sm)", fontSize: 14, cursor: o.disabled ? "default" : "pointer", color: o.disabled ? "var(--color-text-faint)" : "var(--color-text-muted)" },
          onMouseEnter: e => { if (!o.disabled) e.currentTarget.style.background = "rgba(239,235,227,0.06)"; },
          onMouseLeave: e => { e.currentTarget.style.background = "transparent"; }
        }, o.label))));
}