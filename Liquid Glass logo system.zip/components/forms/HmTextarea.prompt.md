Multi-line input for descriptions and agent instructions.
```jsx
<HmTextarea label="Run instructions" rows={4} />
```
Vue API: props { modelValue, label, hint, invalid, rows }, emits ["update:modelValue"].