/** Checkbox with gradient checked state. */
export interface HmCheckboxProps { label?: string; checked?: boolean; disabled?: boolean; onChange?: (checked: boolean) => void; style?: React.CSSProperties; }
export declare function HmCheckbox(props: HmCheckboxProps): JSX.Element;