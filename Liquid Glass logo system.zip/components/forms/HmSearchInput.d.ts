/** Search field with leading glyph and trailing shortcut keycaps. */
export interface HmSearchInputProps {
  placeholder?: string; value?: string; onChange?: (value: string) => void;
  shortcut?: string[] | null; style?: React.CSSProperties;
}
export declare function HmSearchInput(props: HmSearchInputProps): JSX.Element;