import React from "react";
export function HmCheckbox({ label, checked, disabled, onChange, style }) {
  return React.createElement("label", { style: { display: "inline-flex", alignItems: "center", gap: 10, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1, fontFamily: "var(--font-sans)", fontSize: 14, ...style } },
    React.createElement("input", { type: "checkbox", checked: !!checked, disabled, onChange: e => onChange && onChange(e.target.checked), style: { position: "absolute", opacity: 0, width: 18, height: 18 } }),
    React.createElement("span", { "aria-hidden": true, style: {
      width: 18, height: 18, borderRadius: "var(--radius-xs)", flex: "none", display: "inline-flex", alignItems: "center", justifyContent: "center",
      border: checked ? "none" : "1.5px solid var(--color-border-strong)",
      background: checked ? "var(--hm-accent-gradient)" : "transparent",
      color: "var(--color-on-accent)", fontSize: 12, fontWeight: 700,
      transition: "all var(--motion-fast) var(--ease-out)"
    } }, checked ? "✓" : ""),
    label && React.createElement("span", null, label));
}