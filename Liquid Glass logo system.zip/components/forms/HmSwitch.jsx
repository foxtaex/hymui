import React from "react";
export function HmSwitch({ label, checked, disabled, onChange, style }) {
  return React.createElement("label", { style: { display: "inline-flex", alignItems: "center", gap: 12, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1, fontFamily: "var(--font-sans)", fontSize: 14, ...style } },
    React.createElement("input", { type: "checkbox", role: "switch", checked: !!checked, disabled, onChange: e => onChange && onChange(e.target.checked), style: { position: "absolute", opacity: 0 } }),
    React.createElement("span", { "aria-hidden": true, style: {
      width: 40, height: 24, borderRadius: 12, flex: "none", position: "relative",
      background: checked ? "var(--hm-accent-gradient)" : "var(--color-border-strong)",
      transition: "background var(--motion-fast) var(--ease-out)"
    } }, React.createElement("span", { style: {
      position: "absolute", top: 3, left: checked ? 19 : 3, width: 18, height: 18, borderRadius: "50%",
      background: "#FFFFFF", boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
      transition: "left var(--motion-base) var(--spring)"
    } })),
    label && React.createElement("span", null, label));
}