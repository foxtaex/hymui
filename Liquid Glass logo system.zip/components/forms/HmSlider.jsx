import React from "react";
export function HmSlider({ label, min = 0, max = 100, step = 1, value = 50, unit = "", onChange, style }) {
  return React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 8, fontFamily: "var(--font-sans)", ...style } },
    label && React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: "var(--text-label-size)", fontWeight: 600 } },
      React.createElement("span", null, label),
      React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--color-text-muted)", fontWeight: 500 } }, value + unit)),
    React.createElement("input", { type: "range", min, max, step, value,
      onChange: e => onChange && onChange(Number(e.target.value)),
      style: { width: "100%", accentColor: "var(--color-accent)", height: 20, cursor: "pointer" } }));
}