import React from "react";

function FieldWrap({ label, hint, invalid, children }) {
  return React.createElement("label", { style: { display: "flex", flexDirection: "column", gap: 6, fontFamily: "var(--font-sans)" } },
    label && React.createElement("span", { style: { fontSize: "var(--text-label-size)", fontWeight: 600, color: "var(--color-text)" } }, label),
    children,
    hint && React.createElement("span", { style: { fontSize: 12, color: invalid ? "var(--color-danger)" : "var(--color-text-faint)" } }, hint));
}
const inputBase = (invalid, focus, disabled) => ({
  height: "var(--size-control-md)", padding: "0 14px", borderRadius: "var(--radius-md)",
  border: `1px solid ${invalid ? "var(--color-danger)" : focus ? "var(--color-accent)" : "var(--color-border-strong)"}`,
  background: "var(--color-surface-solid)", color: "var(--color-text)",
  fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 500, outline: "none",
  opacity: disabled ? 0.5 : 1, width: "100%", boxSizing: "border-box",
  boxShadow: focus ? "0 0 0 3px var(--color-accent-tint)" : "none",
  transition: "border-color var(--motion-fast) var(--ease-out), box-shadow var(--motion-fast) var(--ease-out)"
});
export function HmTextarea({ label, hint, invalid, disabled, value, defaultValue, placeholder, rows = 4, onChange, style }) {
  const [focus, setFocus] = React.useState(false);
  return React.createElement(FieldWrap, { label, hint, invalid },
    React.createElement("textarea", { value, defaultValue, placeholder, disabled, rows,
      onChange: e => onChange && onChange(e.target.value),
      onFocus: () => setFocus(true), onBlur: () => setFocus(false),
      style: { ...inputBase(invalid, focus, disabled), height: "auto", padding: "10px 14px", resize: "vertical", lineHeight: 1.55, ...style } }));
}