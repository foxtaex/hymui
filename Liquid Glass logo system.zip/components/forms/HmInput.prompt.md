Text field. Invalid state pairs the red border with a hint message — never color alone.
```jsx
<HmInput label="Instance name" hint="Visible to federated peers" onChange={setName} />
```
Vue API: props { modelValue, label, hint, invalid, disabled, readOnly, placeholder, type }, emits ["update:modelValue"].