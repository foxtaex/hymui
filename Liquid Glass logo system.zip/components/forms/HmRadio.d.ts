/** Radio group; selected dot echoes the logo core. */
export interface HmRadioProps { name?: string; options: { value: string; label: string }[]; value?: string; onChange?: (value: string) => void; style?: React.CSSProperties; }
export declare function HmRadio(props: HmRadioProps): JSX.Element;