Radio group for 2–4 exclusive choices; more → HmSelect.
```jsx
<HmRadio options={[{value:"write",label:"Write"},{value:"split",label:"Split"}]} value={m} onChange={setM} />
```
Vue API: props { modelValue, options, name }, emits ["update:modelValue"].