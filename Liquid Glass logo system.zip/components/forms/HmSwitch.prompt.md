Instant-effect settings toggle (no save button).
```jsx
<HmSwitch label="Federation" checked={on} onChange={setOn} />
```
Vue API: props { modelValue, label, disabled }, emits ["update:modelValue"].