/** Multi-line text field. */
export interface HmTextareaProps {
  label?: string; hint?: string; invalid?: boolean; disabled?: boolean;
  value?: string; defaultValue?: string; placeholder?: string; rows?: number;
  onChange?: (value: string) => void; style?: React.CSSProperties;
}
export declare function HmTextarea(props: HmTextareaProps): JSX.Element;