Type-to-filter select; use over HmSelect when options exceed ~8.
```jsx
<HmCombobox label="Assignee" options={people} onChange={assign} />
```
Vue API: props { modelValue, options, label, placeholder }, emits ["update:modelValue", "search"].