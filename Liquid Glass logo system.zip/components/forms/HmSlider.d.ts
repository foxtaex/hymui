/** Range slider with mono value readout. */
export interface HmSliderProps { label?: string; min?: number; max?: number; step?: number; value?: number; unit?: string; onChange?: (value: number) => void; style?: React.CSSProperties; }
export declare function HmSlider(props: HmSliderProps): JSX.Element;