Slider for bounded numeric settings (agent budget, zoom).
```jsx
<HmSlider label="Agent budget" max={50} value={12} unit=" runs" onChange={setB} />
```
Vue API: props { modelValue, label, min, max, step, unit }, emits ["update:modelValue"].