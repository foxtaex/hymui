Search box; ⌘K keycaps hint at the command palette.
```jsx
<HmSearchInput placeholder="Search projects…" onChange={setQuery} />
```
Vue API: props { modelValue, placeholder, shortcut }, emits ["update:modelValue"].