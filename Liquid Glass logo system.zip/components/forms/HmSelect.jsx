import React from "react";
export function HmSelect({ label, options = [], value, placeholder = "Select…", disabled, onChange, style }) {
  const [open, setOpen] = React.useState(false);
  const current = options.find(o => o.value === value);
  return React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 6, position: "relative", fontFamily: "var(--font-sans)", ...style } },
    label && React.createElement("span", { style: { fontSize: "var(--text-label-size)", fontWeight: 600 } }, label),
    React.createElement("button", { disabled, "aria-haspopup": "listbox", "aria-expanded": open, onClick: () => setOpen(!open),
      style: {
        height: "var(--size-control-md)", padding: "0 12px 0 14px", borderRadius: "var(--radius-md)",
        border: `1px solid ${open ? "var(--color-accent)" : "var(--color-border-strong)"}`,
        background: "var(--color-surface-solid)", color: current ? "var(--color-text)" : "var(--color-text-faint)",
        fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 500, cursor: disabled ? "not-allowed" : "pointer",
        display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, width: "100%",
        opacity: disabled ? 0.5 : 1
      } }, React.createElement("span", null, current ? current.label : placeholder), React.createElement("span", { "aria-hidden": true, style: { width: 14, height: 14, backgroundColor: "var(--color-text-faint)", WebkitMaskImage: "url(https://unpkg.com/lucide-static@0.462.0/icons/chevron-down.svg)", maskImage: "url(https://unpkg.com/lucide-static@0.462.0/icons/chevron-down.svg)", WebkitMaskSize: "contain", maskSize: "contain", flex: "none" } })),
    open && React.createElement("div", { role: "listbox", style: {
  position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0, zIndex: 500,
  padding: 6, borderRadius: "var(--radius-lg)", maxHeight: 240, overflowY: "auto",
  background: "linear-gradient(160deg, var(--color-glass-tint), rgba(13,18,17,var(--glass-alpha-overlay)) 70%)",
  backdropFilter: "blur(var(--glass-blur-overlay)) saturate(var(--glass-saturation))",
  WebkitBackdropFilter: "blur(var(--glass-blur-overlay)) saturate(var(--glass-saturation))",
  border: "1px solid var(--color-glass-border)",
  boxShadow: "var(--edge-highlight), var(--shadow-3)", transformOrigin: "top"
} },
      options.map(o => React.createElement("div", { key: o.value, role: "option", "aria-selected": o.value === value,
        onClick: () => { onChange && onChange(o.value); setOpen(false); },
        style: {
          padding: "9px 12px", borderRadius: "var(--radius-sm)", fontSize: 14, cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          color: o.value === value ? "var(--color-text)" : "var(--color-text-muted)",
          background: o.value === value ? "var(--color-accent-tint)" : "transparent"
        },
        onMouseEnter: e => { if (o.value !== value) e.currentTarget.style.background = "rgba(239,235,227,0.06)"; },
        onMouseLeave: e => { if (o.value !== value) e.currentTarget.style.background = "transparent"; }
      }, o.label, o.value === value && React.createElement("span", { style: { color: "var(--color-accent)", fontWeight: 700 } }, "✓")))));
}