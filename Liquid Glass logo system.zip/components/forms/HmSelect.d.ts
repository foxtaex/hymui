/** Custom select — replaces native OS dropdowns everywhere. Opens a Liquid Overlay listbox. */
export interface HmSelectOption { value: string; label: string; }
export interface HmSelectProps {
  label?: string; options: HmSelectOption[]; value?: string; placeholder?: string; disabled?: boolean;
  onChange?: (value: string) => void; style?: React.CSSProperties;
}
export declare function HmSelect(props: HmSelectProps): JSX.Element;