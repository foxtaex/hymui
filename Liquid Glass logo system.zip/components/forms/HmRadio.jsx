import React from "react";
export function HmRadio({ name, options = [], value, onChange, style }) {
  return React.createElement("div", { role: "radiogroup", style: { display: "flex", flexDirection: "column", gap: 10, fontFamily: "var(--font-sans)", fontSize: 14, ...style } },
    options.map(o => React.createElement("label", { key: o.value, style: { display: "inline-flex", alignItems: "center", gap: 10, cursor: "pointer" } },
      React.createElement("input", { type: "radio", name, checked: value === o.value, onChange: () => onChange && onChange(o.value), style: { position: "absolute", opacity: 0 } }),
      React.createElement("span", { "aria-hidden": true, style: {
        width: 18, height: 18, borderRadius: "50%", flex: "none", display: "inline-flex", alignItems: "center", justifyContent: "center",
        border: value === o.value ? "none" : "1.5px solid var(--color-border-strong)",
        background: value === o.value ? "var(--hm-accent-gradient)" : "transparent",
        transition: "all var(--motion-fast) var(--ease-out)"
      } }, value === o.value && React.createElement("span", { style: { width: 6, height: 6, borderRadius: "50%", background: "var(--color-on-accent)" } })),
      React.createElement("span", null, o.label))));
}