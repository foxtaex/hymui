/** Single-line text field with label + hint; solid surface, never glass. */
export interface HmInputProps {
  label?: string; hint?: string; invalid?: boolean; disabled?: boolean; readOnly?: boolean;
  value?: string; defaultValue?: string; placeholder?: string; type?: string;
  onChange?: (value: string) => void; style?: React.CSSProperties;
}
export declare function HmInput(props: HmInputProps): JSX.Element;