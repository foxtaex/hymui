/** On/off toggle with spring thumb. */
export interface HmSwitchProps { label?: string; checked?: boolean; disabled?: boolean; onChange?: (checked: boolean) => void; style?: React.CSSProperties; }
export declare function HmSwitch(props: HmSwitchProps): JSX.Element;