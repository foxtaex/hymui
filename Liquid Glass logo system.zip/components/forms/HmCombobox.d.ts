/** Filterable select for long lists (assignees, projects, boards). */
export interface HmComboboxProps {
  label?: string; options: { value: string; label: string }[]; value?: string; placeholder?: string;
  onChange?: (value: string) => void; style?: React.CSSProperties;
}
export declare function HmCombobox(props: HmComboboxProps): JSX.Element;