import React from "react";
export function HmSearchInput({ placeholder = "Search…", value, onChange, shortcut = ["⌘", "K"], style }) {
  const [focus, setFocus] = React.useState(false);
  return React.createElement("div", { style: { position: "relative", display: "flex", alignItems: "center", ...style } },
    React.createElement("span", { "aria-hidden": true, style: { position: "absolute", left: 12, width: 15, height: 15, backgroundColor: "var(--color-text-faint)", WebkitMaskImage: "url(https://unpkg.com/lucide-static@0.462.0/icons/search.svg)", maskImage: "url(https://unpkg.com/lucide-static@0.462.0/icons/search.svg)", WebkitMaskSize: "contain", maskSize: "contain" } }),
    React.createElement("input", { type: "search", role: "searchbox", placeholder, value,
      onChange: e => onChange && onChange(e.target.value),
      onFocus: () => setFocus(true), onBlur: () => setFocus(false),
      style: {
        height: "var(--size-control-md)", width: "100%", boxSizing: "border-box",
        padding: "0 64px 0 36px", borderRadius: "var(--radius-md)",
        border: `1px solid ${focus ? "var(--color-accent)" : "var(--color-border-strong)"}`,
        background: "var(--color-surface-solid)", color: "var(--color-text)",
        fontFamily: "var(--font-sans)", fontSize: 14, outline: "none",
        boxShadow: focus ? "0 0 0 3px var(--color-accent-tint)" : "none",
        transition: "border-color var(--motion-fast) var(--ease-out)"
      } }),
    shortcut && React.createElement("span", { style: { position: "absolute", right: 10, display: "flex", gap: 3 } },
      shortcut.map((k, i) => React.createElement("kbd", { key: i, style: { fontFamily: "var(--font-mono)", fontSize: 10.5, padding: "3px 5px", borderRadius: 5, border: "1px solid var(--color-border)", color: "var(--color-text-faint)", background: "var(--color-surface-elevated)" } }, k))));
}