Checkbox for filters, task lists, settings.
```jsx
<HmCheckbox label="Assigned to me" checked={v} onChange={setV} />
```
Vue API: props { modelValue, label, disabled }, emits ["update:modelValue"].