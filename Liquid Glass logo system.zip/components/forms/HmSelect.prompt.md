Hymui-styled select (never native). List opens as a Liquid Overlay from the trigger.
```jsx
<HmSelect label="Theme" options={[{value:"dark",label:"Dark"}]} value={theme} onChange={setTheme} />
```
Vue API: props { modelValue, options, label, placeholder, disabled }, emits ["update:modelValue"], slot: option.