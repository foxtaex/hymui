import React from "react";
import { HmLiquidSurface } from "./HmLiquidSurface.jsx";
export function HmLiquidDialog({ open = true, focus = true, width = 380, onClose, children, style, contain }) {
  const pos = contain ? "absolute" : "fixed";
  return React.createElement(React.Fragment, null,
    React.createElement("div", { onClick: onClose, style: {
      position: pos, inset: 0, background: "var(--color-scrim)", zIndex: "var(--z-focus)",
      opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none",
      transition: "opacity var(--motion-depth) var(--ease-out)"
    } }),
    React.createElement(HmLiquidSurface, { level: focus ? "focus" : "overlay", cornerModule: true, role: "dialog", "aria-modal": true, style: {
      position: pos, left: "50%", top: "50%", width, zIndex: "calc(var(--z-focus) + 1)",
      padding: "26px 26px 22px", display: "flex", flexDirection: "column", gap: 14, boxSizing: "border-box",
      opacity: open ? 1 : 0,
      transform: open ? "translate(-50%, -50%) scale(1)" : "translate(-50%, -46%) scale(0.92)",
      pointerEvents: open ? "auto" : "none",
      transition: "opacity var(--motion-depth) var(--spring), transform var(--motion-depth) var(--spring)", ...style
    } }, children));
}