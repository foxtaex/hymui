import React from "react";
import { HmLiquidSurface } from "./HmLiquidSurface.jsx";
export function HmLiquidPopover({ open = true, origin = "top left", width = 240, children, style }) {
  return React.createElement(HmLiquidSurface, { level: "overlay", role: "dialog", style: {
    width, padding: 8, zIndex: "var(--z-overlay)", transformOrigin: origin,
    opacity: open ? 1 : 0, transform: open ? "translateY(0) scale(1)" : "translateY(-8px) scale(0.94)",
    pointerEvents: open ? "auto" : "none",
    transition: "opacity var(--motion-base) var(--spring), transform var(--motion-base) var(--spring)", ...style
  } }, children);
}