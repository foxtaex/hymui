/** Segmented control on glass — connected controls merge; the active segment separates with a spring. */
export interface HmLiquidControlGroupProps {
  items: { value: string; label: string }[];
  value?: string;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}
export declare function HmLiquidControlGroup(props: HmLiquidControlGroupProps): JSX.Element;