import React from "react";
import { HmLiquidSurface } from "./HmLiquidSurface.jsx";
// Connected controls that merge into one glass surface; the active one separates fluidly.
export function HmLiquidControlGroup({ items = [], value, onChange, style }) {
  return React.createElement(HmLiquidSurface, { level: "bar", radius: "var(--radius-xl)", style: { display: "inline-flex", alignItems: "center", padding: 5, ...style } },
    items.map((it, i) => {
      const act = value === it.value;
      const n = items.length;
      const actIdx = items.findIndex(x => x.value === value);
      const rL = (i === 0 || act || actIdx === i - 1) ? 16 : 6;
      const rR = (i === n - 1 || act || actIdx === i + 1) ? 16 : 6;
      return React.createElement("button", { key: it.value, onClick: () => onChange && onChange(it.value), "aria-pressed": act, style: {
        position: "relative", border: "none", fontFamily: "var(--font-sans)", padding: "9px 20px",
        fontSize: 13.5, fontWeight: 600, cursor: "pointer",
        color: act ? "var(--color-on-accent)" : "var(--color-text-muted)",
        background: act ? "var(--hm-accent-gradient)" : "rgba(239,235,227,0.04)",
        borderRadius: `${rL}px ${rR}px ${rR}px ${rL}px`,
        margin: act ? (i === 0 ? "0 9px 0 0" : i === n - 1 ? "0 0 0 9px" : "0 9px") : "0 1px",
        transform: act ? "translateY(-2px) scale(1.04)" : "none",
        boxShadow: act ? "var(--shadow-accent), inset 0 1px 0 rgba(255,255,255,0.35)" : "inset 0 1px 0 rgba(255,255,255,0.05)",
        transition: "all var(--motion-soft) var(--spring)"
      } }, it.label);
    }));
}