On-glass button: invisible at rest, soft fill on hover, gradient when active. Only inside Liquid surfaces.
```jsx
<HmLiquidBar><HmLiquidButton active>Board</HmLiquidButton><HmLiquidButton>Docs</HmLiquidButton></HmLiquidBar>
```
Vue API: props { active, size }, emits ["click"], slot: default.