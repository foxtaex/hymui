/** Base Liquid Glass material — every glass component composes this. */
export interface HmLiquidSurfaceProps {
  level?: "bar" | "panel" | "overlay" | "focus";
  cornerModule?: boolean;  /* logo-module corner detail (panels, dialogs) */
  centerDot?: boolean;     /* mint status dot */
  sheen?: boolean;         /* pointer-tracked highlight; auto-disabled by reduced transparency */
  radius?: string | number;
  as?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
export declare function HmLiquidSurface(props: HmLiquidSurfaceProps): JSX.Element;