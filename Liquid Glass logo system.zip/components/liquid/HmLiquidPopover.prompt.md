Overlay container; set transform-origin to the trigger corner so it expands from it.
```jsx
<HmLiquidPopover open={open} origin="top left">…menu items…</HmLiquidPopover>
```
Vue API: props { open, origin, width }, emits ["close"], slot: default.