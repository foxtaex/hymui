import React from "react";
export function HmLiquidButton({ active, size = "md", children, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const pads = { sm: "6px 12px", md: "8px 16px", lg: "11px 22px" };
  return React.createElement("button", { onClick,
    onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
    style: {
      border: "none", fontFamily: "var(--font-sans)", padding: pads[size] || pads.md,
      borderRadius: "var(--radius-md)", fontSize: size === "sm" ? 13 : 14, fontWeight: active ? 600 : 500, cursor: "pointer",
      color: active ? "var(--color-on-accent)" : hover ? "var(--color-text)" : "var(--color-text-muted)",
      background: active ? "var(--hm-accent-gradient)" : hover ? "rgba(239,235,227,0.07)" : "transparent",
      boxShadow: active ? "var(--shadow-accent), inset 0 1px 0 rgba(255,255,255,0.35)" : "none",
      transition: "all var(--motion-fast) var(--ease-out)", ...style
    } }, children);
}