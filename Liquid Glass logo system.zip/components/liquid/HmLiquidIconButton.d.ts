/** Icon-only on-glass button; label required. */
export interface HmLiquidIconButtonProps { label: string; active?: boolean; size?: number; children?: React.ReactNode; onClick?: () => void; style?: React.CSSProperties; }
export declare function HmLiquidIconButton(props: HmLiquidIconButtonProps): JSX.Element;