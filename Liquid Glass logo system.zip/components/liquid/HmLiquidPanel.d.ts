/** Level-2 glass: sidebars, inspectors, filters, settings nav. */
export interface HmLiquidPanelProps { width?: number | string; cornerModule?: boolean; children?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmLiquidPanel(props: HmLiquidPanelProps): JSX.Element;