import React from "react";
import { HmLiquidSurface } from "./HmLiquidSurface.jsx";
export function HmLiquidBar({ floating = true, children, style }) {
  return React.createElement(HmLiquidSurface, { level: "bar", as: "nav", style: {
    display: "inline-flex", alignItems: "center", gap: 14, padding: "8px 12px",
    zIndex: "var(--z-bar)", ...(floating ? { boxShadow: "var(--edge-highlight), var(--shadow-2)" } : {}), ...style
  } }, children);
}