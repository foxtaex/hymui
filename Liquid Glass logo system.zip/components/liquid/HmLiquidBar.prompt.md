Compact floating toolbar/nav. Separate control clusters with <HmSeparator dot />.
```jsx
<HmLiquidBar><Logo /><HmSeparator dot /><HmLiquidButton active>Board</HmLiquidButton></HmLiquidBar>
```
Vue API: props { floating }, slot: default.