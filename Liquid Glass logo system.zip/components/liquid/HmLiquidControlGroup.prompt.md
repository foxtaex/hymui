View switcher (Board/Timeline/Table, Write/Preview/Split). The signature merge/separate motion.
```jsx
<HmLiquidControlGroup items={[{value:"board",label:"Board"}]} value={v} onChange={setV} />
```
Vue API: props { items, modelValue }, emits ["update:modelValue"].