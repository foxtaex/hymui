Sidebar/inspector panel; carries the modular corner signature by default.
```jsx
<HmLiquidPanel width={264}>…nav items…</HmLiquidPanel>
```
Vue API: props { width, cornerModule }, slot: default.