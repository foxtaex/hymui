/** Level-3 glass: popover/dropdown container that springs from its trigger. */
export interface HmLiquidPopoverProps { open?: boolean; origin?: string; width?: number | string; children?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmLiquidPopover(props: HmLiquidPopoverProps): JSX.Element;