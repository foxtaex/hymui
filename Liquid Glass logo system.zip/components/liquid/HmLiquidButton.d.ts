/** Button that lives ON glass surfaces — transparent at rest, merging into the material. */
export interface HmLiquidButtonProps { active?: boolean; size?: "sm" | "md" | "lg"; children?: React.ReactNode; onClick?: () => void; style?: React.CSSProperties; }
export declare function HmLiquidButton(props: HmLiquidButtonProps): JSX.Element;