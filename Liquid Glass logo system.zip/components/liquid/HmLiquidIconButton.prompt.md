Icon button for Liquid Bars and whiteboard toolbars.
```jsx
<HmLiquidIconButton label="Zoom in"><HmIcon name="plus" /></HmLiquidIconButton>
```
Vue API: props { label (required), active, size }, emits ["click"], slot: default.