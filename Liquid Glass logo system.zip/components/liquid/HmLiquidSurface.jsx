import React from "react";
// Base Liquid Glass material. All glass in Hymui composes this — never re-implement blur locally.
export function HmLiquidSurface({ level = "panel", cornerModule, centerDot, sheen = true, radius, as = "div", style, children, ...rest }) {
  const ref = React.useRef(null);
  const r = radius != null ? radius : { bar: "var(--radius-xl)", panel: "var(--radius-2xl)", overlay: "var(--radius-xl)", focus: "var(--radius-2xl)" }[level];
  const onMove = sheen ? (e) => {
    const el = ref.current; if (!el) return;
    const b = el.getBoundingClientRect();
    el.style.setProperty("--mx", (((e.clientX - b.left) / b.width) * 100).toFixed(1) + "%");
    el.style.setProperty("--my", (((e.clientY - b.top) / b.height) * 100).toFixed(1) + "%");
  } : undefined;
  return React.createElement(as, { ref, onMouseMove: onMove, ...rest, style: {
    position: "relative", borderRadius: r,
    background: `linear-gradient(160deg, var(--color-glass-tint), rgba(13,18,17,var(--glass-alpha-${level})) 70%)`,
    backdropFilter: `blur(var(--glass-blur-${level})) saturate(var(--glass-saturation))`,
    WebkitBackdropFilter: `blur(var(--glass-blur-${level})) saturate(var(--glass-saturation))`,
    border: level === "focus" ? "1px solid rgba(15,191,174,0.4)" : "1px solid var(--color-glass-border)",
    boxShadow: `var(--edge-highlight), ${level === "focus" ? "0 0 0 1px rgba(15,191,174,0.12), var(--shadow-4)" : level === "overlay" ? "var(--shadow-3)" : "var(--shadow-2)"}`,
    ...style
  } },
    sheen && React.createElement("div", { "aria-hidden": true, style: {
      position: "absolute", inset: 0, borderRadius: r, pointerEvents: "none",
      background: "radial-gradient(320px circle at var(--mx, 50%) var(--my, -40%), rgba(239,235,227,calc(var(--glass-highlight-opacity) * 0.11)), transparent 58%)"
    } }),
    cornerModule && React.createElement("div", { "aria-hidden": true, style: {
      position: "absolute", top: 10, left: 10, width: 14, height: 14,
      borderTop: "2px solid rgba(15,191,174,0.55)", borderLeft: "2px solid rgba(15,191,174,0.55)", borderTopLeftRadius: 8
    } }),
    centerDot && React.createElement("div", { "aria-hidden": true, style: {
      position: "absolute", top: 14, right: 14, width: 5, height: 5, borderRadius: "50%",
      background: "var(--color-accent)", boxShadow: "0 0 8px rgba(15,191,174,0.8)"
    } }),
    children);
}