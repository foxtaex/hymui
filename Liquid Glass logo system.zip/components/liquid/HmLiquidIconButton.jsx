import React from "react";
export function HmLiquidIconButton({ label, active, size = 36, children, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  return React.createElement("button", { "aria-label": label, title: label, onClick,
    onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
    style: {
      width: size, height: size, display: "inline-flex", alignItems: "center", justifyContent: "center",
      border: "none", borderRadius: "var(--radius-md)", cursor: "pointer",
      color: active ? "var(--color-accent)" : hover ? "var(--color-text)" : "var(--color-text-muted)",
      background: active ? "var(--color-accent-tint)" : hover ? "rgba(239,235,227,0.07)" : "transparent",
      transition: "all var(--motion-fast) var(--ease-out)", ...style
    } }, children);
}