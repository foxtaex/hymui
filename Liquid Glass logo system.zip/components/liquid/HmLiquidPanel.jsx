import React from "react";
import { HmLiquidSurface } from "./HmLiquidSurface.jsx";
export function HmLiquidPanel({ width, cornerModule = true, children, style }) {
  return React.createElement(HmLiquidSurface, { level: "panel", as: "aside", cornerModule, style: {
    width: width || "var(--sidebar-width)", padding: "18px 14px", zIndex: "var(--z-panel)",
    display: "flex", flexDirection: "column", gap: 4, boxSizing: "border-box", ...style
  } }, children);
}