The glass material. Levels: bar (blur 22/α.30) · panel (26/.44) · overlay (32/.62) · focus (36/.88, mint edge).
```jsx
<HmLiquidSurface level="panel" cornerModule style={{ padding: 20 }}>…</HmLiquidSurface>
```
Content that people read at length never goes ON glass — glass frames solid surfaces.
Vue API: props { level, cornerModule, centerDot, sheen, radius }, slot: default.