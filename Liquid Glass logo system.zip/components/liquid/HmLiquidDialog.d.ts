/** Level-4 glass dialog with scrim. focus=true gives highest clarity + mint edge (AI approvals, destructive confirms). */
export interface HmLiquidDialogProps {
  open?: boolean; focus?: boolean; width?: number | string; contain?: boolean;
  onClose?: () => void; children?: React.ReactNode; style?: React.CSSProperties;
}
export declare function HmLiquidDialog(props: HmLiquidDialogProps): JSX.Element;