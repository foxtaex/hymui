/** Level-1 glass: floating nav / toolbar strip. Children merge into one surface. */
export interface HmLiquidBarProps { floating?: boolean; children?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmLiquidBar(props: HmLiquidBarProps): JSX.Element;