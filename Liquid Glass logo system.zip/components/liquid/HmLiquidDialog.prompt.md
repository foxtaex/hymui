Modal on the Focus level: near-solid behind text, mint focus edge, strong scrim.
```jsx
<HmLiquidDialog open={open} onClose={close}>
  <h3>Approve agent run?</h3> … <HmButton>Approve</HmButton>
</HmLiquidDialog>
```
Vue API: props { open, focus, width }, emits ["close"], slots: default, actions.