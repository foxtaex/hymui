Toast; state carried by dot + words, never color alone. Stack bottom-right, newest on top.
```jsx
<HmToast tone="success" title="Card restored" description="To board · Release 1.4" action="Open" />
```
Vue API: props { tone, title, description, action }, emits ["action", "dismiss"].