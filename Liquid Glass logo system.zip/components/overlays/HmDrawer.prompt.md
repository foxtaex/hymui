Floating drawer with 12px inset — glass panels never touch screen edges.
```jsx
<HmDrawer open={open} onClose={close}>…card details…</HmDrawer>
```
Vue API: props { open, side, width }, emits ["close"], slot: default.