Permission state; never a dead end — offer "Request access".
```jsx
<HmPermissionState action={<HmButton variant="secondary">Request access</HmButton>} />
```