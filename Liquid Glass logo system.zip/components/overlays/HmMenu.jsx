import React from "react";
import { HmLiquidPopover } from "../liquid/HmLiquidPopover.jsx";
export function HmMenuItem({ label, icon, shortcut = [], danger, disabled, onClick }) {
  const [hover, setHover] = React.useState(false);
  return React.createElement("div", { role: "menuitem", "aria-disabled": disabled, onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
    style: {
      display: "flex", alignItems: "center", gap: 10, padding: "9px 12px",
      borderRadius: "var(--radius-sm)", fontSize: 14, fontFamily: "var(--font-sans)",
      cursor: disabled ? "default" : "pointer", opacity: disabled ? 0.45 : 1,
      color: danger ? "var(--color-danger)" : "var(--color-text)",
      background: hover && !disabled ? (danger ? "var(--color-danger-tint)" : "rgba(239,235,227,0.07)") : "transparent",
      transition: "background var(--motion-fast) var(--ease-out)"
    } },
    icon && React.createElement("span", { style: { display: "inline-flex", width: 16, color: danger ? "var(--color-danger)" : "var(--color-text-muted)" } }, icon),
    React.createElement("span", { style: { flex: 1 } }, label),
    shortcut.length > 0 && React.createElement("span", { style: { display: "flex", gap: 3 } },
      shortcut.map((k, i) => React.createElement("span", { key: i, style: { fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--color-text-faint)" } }, k))));
}
export function HmMenuSeparator() {
  return React.createElement("div", { role: "separator", style: { height: 1, background: "var(--color-border)", margin: "5px 8px" } });
}
export function HmMenu({ open = true, width = 230, origin = "top left", children, style }) {
  return React.createElement(HmLiquidPopover, { open, width, origin, role: "menu", style }, children);
}