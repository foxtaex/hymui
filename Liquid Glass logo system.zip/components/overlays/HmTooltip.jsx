import React from "react";
export function HmTooltip({ label, shortcut = [], children }) {
  const [show, setShow] = React.useState(false);
  return React.createElement("span", { style: { position: "relative", display: "inline-flex" },
    onMouseEnter: () => setShow(true), onMouseLeave: () => setShow(false) },
    children,
    React.createElement("span", { role: "tooltip", style: {
      position: "absolute", bottom: "calc(100% + 8px)", left: "50%",
      transform: show ? "translateX(-50%) translateY(0)" : "translateX(-50%) translateY(3px)",
      opacity: show ? 1 : 0, pointerEvents: "none", whiteSpace: "nowrap", zIndex: "var(--z-overlay)",
      display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 10px",
      borderRadius: "var(--radius-sm)", fontSize: 12, fontFamily: "var(--font-sans)", fontWeight: 500,
      background: "rgba(13,18,17,0.92)", color: "var(--color-text)",
      border: "1px solid var(--color-glass-border)", boxShadow: "var(--edge-highlight), var(--shadow-2)",
      backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)",
      transition: "all var(--motion-fast) var(--ease-out)"
    } }, label, shortcut.length > 0 && React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--color-text-faint)" } }, shortcut.join(""))));
}