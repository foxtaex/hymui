import React from "react";
import { HmLiquidDialog } from "../liquid/HmLiquidDialog.jsx";
import { HmButton } from "../core/HmButton.jsx";
export function HmConfirmDialog({ open = true, title, description, confirmLabel = "Confirm", cancelLabel = "Cancel", destructive, onConfirm, onCancel, icon, contain }) {
  return React.createElement(HmLiquidDialog, { open, focus: true, width: 360, onClose: onCancel, contain },
    React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
      icon, React.createElement("div", { style: { fontSize: 16, fontWeight: 600, fontFamily: "var(--font-sans)", color: "var(--color-text)" } }, title)),
    React.createElement("div", { style: { fontSize: 13.5, lineHeight: 1.6, color: "var(--color-text-muted)", fontFamily: "var(--font-sans)" } }, description),
    React.createElement("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end", paddingTop: 4 } },
      React.createElement(HmButton, { variant: "secondary", size: "sm", onClick: onCancel }, cancelLabel),
      destructive
        ? React.createElement(HmButton, { variant: "danger", size: "sm", onClick: onConfirm, style: { border: "1px solid var(--color-danger)", background: "var(--color-danger-tint)" } }, confirmLabel)
        : React.createElement(HmButton, { variant: "primary", size: "sm", onClick: onConfirm }, confirmLabel)));
}