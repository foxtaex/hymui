Dropdown menu; destructive items are red and sit last, after a separator.
```jsx
<HmMenu open={open}>
  <HmMenuItem label="Rename" shortcut={["⌘","R"]} />
  <HmMenuSeparator />
  <HmMenuItem label="Delete board" danger />
</HmMenu>
```
Vue API: HmMenu props { open, width, origin }; item props { label, shortcut, danger, disabled }, emits ["select"].