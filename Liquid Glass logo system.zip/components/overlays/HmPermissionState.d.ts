/** Permission-denied block; names who can grant access. */
export interface HmPermissionStateProps { title?: string; description?: string; action?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmPermissionState(props: HmPermissionStateProps): JSX.Element;