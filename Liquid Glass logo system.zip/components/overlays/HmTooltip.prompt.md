Tooltip wrapper; include the shortcut when the control has one.
```jsx
<HmTooltip label="Search" shortcut={["⌘","K"]}><HmIconButton label="Search">…</HmIconButton></HmTooltip>
```
Vue API: props { label, shortcut }, slot: default.