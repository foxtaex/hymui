/** Standard dialog (Overlay level). For approvals/destructive use HmConfirmDialog (Focus level). */
export interface HmDialogProps { open?: boolean; title?: string; width?: number; contain?: boolean; onClose?: () => void; children?: React.ReactNode; actions?: React.ReactNode; }
export declare function HmDialog(props: HmDialogProps): JSX.Element;