import React from "react";
import { HmLiquidPopover } from "../liquid/HmLiquidPopover.jsx";
export function HmPopover({ open = true, width = 260, origin = "top left", title, children, style }) {
  return React.createElement(HmLiquidPopover, { open, width, origin, style: { padding: 14, ...style } },
    title && React.createElement("div", { style: { fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--color-text-faint)", padding: "2px 2px 10px" } }, title),
    children);
}