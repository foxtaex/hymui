/** Focus-level confirmation: AI approvals, destructive actions, security-sensitive decisions. */
export interface HmConfirmDialogProps {
  open?: boolean; title: string; description?: string; confirmLabel?: string; cancelLabel?: string;
  destructive?: boolean; contain?: boolean; icon?: React.ReactNode; onConfirm?: () => void; onCancel?: () => void;
}
export declare function HmConfirmDialog(props: HmConfirmDialogProps): JSX.Element;