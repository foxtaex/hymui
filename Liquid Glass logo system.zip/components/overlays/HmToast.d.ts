/** Transient notification card; status dot + optional action. */
export interface HmToastProps { tone?: "neutral" | "success" | "warning" | "danger"; title: string; description?: string; action?: string; onAction?: () => void; style?: React.CSSProperties; }
export declare function HmToast(props: HmToastProps): JSX.Element;