/** Recoverable error block with retry action. */
export interface HmErrorStateProps { title?: string; description?: string; action?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmErrorState(props: HmErrorStateProps): JSX.Element;