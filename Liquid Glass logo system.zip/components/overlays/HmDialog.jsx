import React from "react";
import { HmLiquidDialog } from "../liquid/HmLiquidDialog.jsx";
export function HmDialog({ open = true, title, width = 420, onClose, children, actions, contain }) {
  return React.createElement(HmLiquidDialog, { open, focus: false, width, onClose, contain },
    title && React.createElement("div", { style: { fontSize: 17, fontWeight: 600, fontFamily: "var(--font-sans)", color: "var(--color-text)" } }, title),
    React.createElement("div", { style: { fontSize: 14, lineHeight: 1.6, color: "var(--color-text-muted)", fontFamily: "var(--font-sans)" } }, children),
    actions && React.createElement("div", { style: { display: "flex", gap: 10, justifyContent: "flex-end", paddingTop: 4 } }, actions));
}