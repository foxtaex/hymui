/** ⌘K palette on Overlay glass with grouped results. */
export interface HmCommandPaletteProps {
  open?: boolean; query?: string; contain?: boolean;
  onQuery?: (q: string) => void;
  groups?: { label: string; items: { label: string; icon?: React.ReactNode; meta?: string }[] }[];
  onSelect?: (item: any) => void;
}
export declare function HmCommandPalette(props: HmCommandPaletteProps): JSX.Element;