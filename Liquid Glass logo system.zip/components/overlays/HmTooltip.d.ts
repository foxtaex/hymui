/** Hover tooltip; near-solid for legibility (accessibility-critical surface). */
export interface HmTooltipProps { label: string; shortcut?: string[]; children?: React.ReactNode; }
export declare function HmTooltip(props: HmTooltipProps): JSX.Element;