/** CRDT/merge conflict block; action opens the conflict view. */
export interface HmConflictStateProps { title?: string; description?: string; action?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmConflictState(props: HmConflictStateProps): JSX.Element;