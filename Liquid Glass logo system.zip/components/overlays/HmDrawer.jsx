import React from "react";
import { HmLiquidSurface } from "../liquid/HmLiquidSurface.jsx";
export function HmDrawer({ open = true, side = "right", width = 360, onClose, children, contain }) {
  const pos = contain ? "absolute" : "fixed";
  return React.createElement(React.Fragment, null,
    React.createElement("div", { onClick: onClose, style: {
      position: pos, inset: 0, background: "var(--color-scrim)", zIndex: "var(--z-overlay)",
      opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none", transition: "opacity var(--motion-depth) var(--ease-out)"
    } }),
    React.createElement(HmLiquidSurface, { level: "panel", cornerModule: true, style: {
      position: pos, top: 12, bottom: 12, [side]: 12, width, zIndex: "calc(var(--z-overlay) + 1)",
      padding: 20, boxSizing: "border-box", overflowY: "auto",
      transform: open ? "translateX(0)" : `translateX(${side === "right" ? "40px" : "-40px"})`,
      opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none",
      transition: "transform var(--motion-soft) var(--spring), opacity var(--motion-soft) var(--ease-out)"
    } }, children));
}