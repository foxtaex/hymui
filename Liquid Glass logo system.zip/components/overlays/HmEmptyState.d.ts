/** Empty state with the outline mark; always offers the next step. */
export interface HmEmptyStateProps { title?: string; description?: string; action?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmEmptyState(props: HmEmptyStateProps): JSX.Element;