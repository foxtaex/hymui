import React from "react";
import { HmLiquidSurface } from "../liquid/HmLiquidSurface.jsx";
export function HmCommandPalette({ open = true, query = "", onQuery, groups = [], onSelect, contain }) {
  const pos = contain ? "absolute" : "fixed";
  return React.createElement(React.Fragment, null,
    React.createElement("div", { style: { position: pos, inset: 0, background: "var(--color-scrim)", zIndex: "var(--z-overlay)", opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none", transition: "opacity var(--motion-base) var(--ease-out)" } }),
    React.createElement(HmLiquidSurface, { level: "overlay", cornerModule: true, style: {
      position: pos, left: "50%", top: "18%", transform: open ? "translateX(-50%) scale(1)" : "translateX(-50%) scale(0.96)",
      width: 520, maxWidth: "90%", zIndex: "calc(var(--z-overlay) + 1)", boxSizing: "border-box",
      opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none", padding: 10,
      transition: "all var(--motion-base) var(--spring)", transformOrigin: "top center"
    } },
      React.createElement("input", { autoFocus: open, placeholder: "Type a command or search…", value: query,
        onChange: e => onQuery && onQuery(e.target.value),
        style: {
          width: "100%", boxSizing: "border-box", height: 44, padding: "0 14px", fontSize: 15,
          fontFamily: "var(--font-sans)", fontWeight: 500, color: "var(--color-text)",
          background: "rgba(239,235,227,0.05)", border: "1px solid var(--color-border)",
          borderRadius: "var(--radius-md)", outline: "none"
        } }),
      React.createElement("div", { style: { maxHeight: 320, overflowY: "auto", marginTop: 6 } },
        groups.map((g, gi) => React.createElement("div", { key: gi },
          React.createElement("div", { style: { fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--color-text-faint)", padding: "10px 12px 4px" } }, g.label),
          g.items.map((it, i) => React.createElement("div", { key: i, onClick: () => onSelect && onSelect(it),
            onMouseEnter: e => e.currentTarget.style.background = "rgba(239,235,227,0.07)",
            onMouseLeave: e => e.currentTarget.style.background = "transparent",
            style: { display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderRadius: "var(--radius-sm)", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--color-text)" } },
            it.icon && React.createElement("span", { style: { display: "inline-flex", color: "var(--color-text-muted)" } }, it.icon),
            React.createElement("span", { style: { flex: 1 } }, it.label),
            it.meta && React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--color-text-faint)" } }, it.meta)))))));
}