/** Slide-in side panel (card details, responsive nav). Floats inset, never edge-glued. */
export interface HmDrawerProps { open?: boolean; side?: "left" | "right"; width?: number; contain?: boolean; onClose?: () => void; children?: React.ReactNode; }
export declare function HmDrawer(props: HmDrawerProps): JSX.Element;