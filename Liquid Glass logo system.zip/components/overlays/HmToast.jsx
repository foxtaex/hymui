import React from "react";
import { HmLiquidSurface } from "../liquid/HmLiquidSurface.jsx";
export function HmToast({ tone = "neutral", title, description, action, onAction, style }) {
  const tones = { neutral: "var(--hm-mint-subtle)", success: "var(--color-success)", warning: "var(--color-warning)", danger: "var(--color-danger)" };
  return React.createElement(HmLiquidSurface, { level: "overlay", radius: "var(--radius-lg)", sheen: false, role: "status", style: {
    display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", width: 340, boxSizing: "border-box", zIndex: "var(--z-toast)", ...style
  } },
    React.createElement("span", { style: { width: 6, height: 6, borderRadius: "50%", flex: "none", background: tones[tone], boxShadow: `0 0 8px ${tones[tone]}` } }),
    React.createElement("div", { style: { flex: 1, fontFamily: "var(--font-sans)" } },
      React.createElement("div", { style: { fontSize: 13.5, fontWeight: 600, color: "var(--color-text)" } }, title),
      description && React.createElement("div", { style: { fontSize: 12.5, color: "var(--color-text-muted)", marginTop: 2 } }, description)),
    action && React.createElement("button", { onClick: onAction, style: {
      border: "none", background: "transparent", color: "var(--color-accent)", fontFamily: "var(--font-sans)",
      fontSize: 13, fontWeight: 600, cursor: "pointer", padding: "6px 8px", borderRadius: 8
    } }, action));
}