/** Menu on Liquid Overlay glass; also exports HmMenuItem and HmMenuSeparator. */
export interface HmMenuProps { open?: boolean; width?: number; origin?: string; children?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmMenu(props: HmMenuProps): JSX.Element;
export declare function HmMenuItem(props: { label: string; icon?: React.ReactNode; shortcut?: string[]; danger?: boolean; disabled?: boolean; onClick?: () => void }): JSX.Element;
export declare function HmMenuSeparator(): JSX.Element;