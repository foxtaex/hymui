Global ⌘K. Groups: Actions, Projects, Docs, Agents. Meta column shows type/shortcut in mono.
```jsx
<HmCommandPalette open={open} groups={[{label:"Actions",items:[{label:"New board", meta:"⌘B"}]}]} />
```
Vue API: props { open, query, groups }, emits ["update:query", "select", "close"].