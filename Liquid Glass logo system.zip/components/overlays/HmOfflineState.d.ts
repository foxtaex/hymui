/** Local-first offline notice — calm, not alarming. */
export interface HmOfflineStateProps { title?: string; description?: string; action?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmOfflineState(props: HmOfflineStateProps): JSX.Element;