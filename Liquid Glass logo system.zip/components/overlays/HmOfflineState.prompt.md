Offline is normal in Hymui — reassuring tone, local-save emphasized.
```jsx
<HmOfflineState />
```