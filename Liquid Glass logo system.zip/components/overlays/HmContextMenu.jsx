import React from "react";
import { HmMenu } from "./HmMenu.jsx";
export function HmContextMenu({ x = 0, y = 0, open = true, children, style }) {
  return React.createElement("div", { style: { position: "absolute", left: x, top: y, zIndex: "var(--z-overlay)" } },
    React.createElement(HmMenu, { open, origin: "top left", style }, children));
}