Context menu at pointer position; same items as HmMenu.
```jsx
<HmContextMenu x={pt.x} y={pt.y} open={open}>…items…</HmContextMenu>
```
Vue API: props { x, y, open }, emits ["close"].