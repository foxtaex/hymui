/** General content popover (filters, pickers) with optional mono title. */
export interface HmPopoverProps { open?: boolean; width?: number; origin?: string; title?: string; children?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmPopover(props: HmPopoverProps): JSX.Element;