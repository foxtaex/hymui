General modal for non-critical flows (event details, pickers).
```jsx
<HmDialog open={open} title="New event" actions={<HmButton>Save</HmButton>}>…form…</HmDialog>
```
Vue API: props { open, title, width }, emits ["close"], slots: default, actions.