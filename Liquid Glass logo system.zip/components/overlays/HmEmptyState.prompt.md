Empty state; description says what belongs here, action creates it.
```jsx
<HmEmptyState title="No boards yet" description="Boards track work as cards in columns." action={<HmButton>New board</HmButton>} />
```
Vue API: props { title, description }, slots: action.