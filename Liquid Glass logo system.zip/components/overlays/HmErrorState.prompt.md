Error block: plain-language cause + retry.
```jsx
<HmErrorState description="The peer stopped responding while syncing." action={<HmButton variant="secondary">Retry</HmButton>} />
```