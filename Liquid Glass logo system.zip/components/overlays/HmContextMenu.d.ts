/** Right-click menu positioned at pointer coordinates. */
export interface HmContextMenuProps { x?: number; y?: number; open?: boolean; children?: React.ReactNode; style?: React.CSSProperties; }
export declare function HmContextMenu(props: HmContextMenuProps): JSX.Element;