import React from "react";
export function HmStateBlock({ icon, title, description, action, tone = "neutral", style }) {
  const colors = { neutral: "var(--hm-mint-subtle)", danger: "var(--color-danger)", warning: "var(--color-warning)" };
  return React.createElement("div", { style: {
    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center",
    gap: 12, padding: "44px 32px", fontFamily: "var(--font-sans)", ...style
  } },
    React.createElement("div", { style: { color: colors[tone], opacity: 0.85 } }, icon),
    React.createElement("div", { style: { fontSize: 15.5, fontWeight: 600, color: "var(--color-text)" } }, title),
    description && React.createElement("div", { style: { fontSize: 13.5, lineHeight: 1.6, color: "var(--color-text-muted)", maxWidth: 340 } }, description),
    action && React.createElement("div", { style: { marginTop: 6 } }, action));
}
const mark = (color) => React.createElement("svg", { viewBox: "0 0 72 72", style: { width: 34, height: 34 } },
  React.createElement("g", { fill: "none", stroke: "currentColor", strokeWidth: 4.5, strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("path", { d: "M16 28 L16 16 L36 16" }),
    React.createElement("path", { d: "M16 28 L16 16 L36 16", transform: "rotate(90 36 36)" }),
    React.createElement("path", { d: "M16 28 L16 16 L36 16", transform: "rotate(180 36 36)" }),
    React.createElement("path", { d: "M16 28 L16 16 L36 16", transform: "rotate(270 36 36)" })),
  React.createElement("circle", { cx: 36, cy: 36, r: 4, fill: "currentColor" }));
export function HmOfflineState({ title = "Working offline", description = "Changes are saved locally and will sync when your instance reconnects.", action, style }) {
  return React.createElement(HmStateBlock, { icon: mark(), tone: "warning", title, description, action, style });
}