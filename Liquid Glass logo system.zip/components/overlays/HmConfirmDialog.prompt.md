The Liquid Focus confirmation. Copy states exactly what changes: "Scout will merge 12 duplicate tasks across 3 boards."
```jsx
<HmConfirmDialog title="Approve agent run?" description="…" confirmLabel="Approve" onConfirm={ok} />
```
Vue API: props { open, title, description, confirmLabel, cancelLabel, destructive }, emits ["confirm", "cancel"].