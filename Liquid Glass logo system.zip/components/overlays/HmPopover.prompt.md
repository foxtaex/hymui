Rich popover for filters/pickers; springs from its trigger.
```jsx
<HmPopover open={open} title="Show only"><HmCheckbox label="Assigned to me" /></HmPopover>
```
Vue API: props { open, width, origin, title }, emits ["close"], slot: default.