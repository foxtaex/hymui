Conflict notice; action = "Review versions" → DocsConflictView.
```jsx
<HmConflictState action={<HmButton variant="secondary">Review versions</HmButton>} />
```