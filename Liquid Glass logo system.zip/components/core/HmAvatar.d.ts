/** Person or agent identity. agent=true renders the hy-mark-line glyph. */
export interface HmAvatarProps {
  name?: string;
  src?: string;
  size?: number;
  agent?: boolean;
  style?: React.CSSProperties;
}
export declare function HmAvatar(props: HmAvatarProps): JSX.Element;