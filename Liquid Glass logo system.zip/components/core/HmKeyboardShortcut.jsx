import React from "react";
export function HmKeyboardShortcut({ keys = [], style }) {
  return React.createElement("span", { style: { display: "inline-flex", gap: 4, ...style } },
    keys.map((k, i) => React.createElement("kbd", { key: i, style: {
      fontFamily: "var(--font-mono)", fontSize: "var(--text-kbd-size)", lineHeight: 1,
      padding: "4px 6px", minWidth: 12, textAlign: "center",
      borderRadius: "var(--radius-xs)", border: "1px solid var(--color-border-strong)",
      background: "var(--color-surface-elevated)", color: "var(--color-text-muted)",
      boxShadow: "inset 0 -1px 0 var(--color-border)" } }, k)));
}