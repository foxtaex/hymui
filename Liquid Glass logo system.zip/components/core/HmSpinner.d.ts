/** Indeterminate mint arc spinner. */
export interface HmSpinnerProps { size?: number; style?: React.CSSProperties; }
export declare function HmSpinner(props: HmSpinnerProps): JSX.Element;