import React from "react";
if (typeof document !== "undefined" && !document.getElementById("hm-skeleton-kf")) {
  const s = document.createElement("style"); s.id = "hm-skeleton-kf";
  s.textContent = "@keyframes hm-shimmer { 0% { opacity: 0.5; } 50% { opacity: 1; } 100% { opacity: 0.5; } }";
  document.head.appendChild(s);
}
export function HmSkeleton({ width = "100%", height = 12, radius = 6, style }) {
  return React.createElement("div", { "aria-hidden": true, style: { width, height, borderRadius: radius, background: "var(--color-border)", animation: "hm-shimmer 1.6s var(--ease-in-out) infinite", ...style } });
}