import React from "react";
export function HmSpinner({ size = 18, style }) {
  return React.createElement("svg", { viewBox: "0 0 24 24", role: "status", "aria-label": "Loading", style: { width: size, height: size, ...style } },
    React.createElement("circle", { cx: 12, cy: 12, r: 9, fill: "none", stroke: "var(--color-border-strong)", strokeWidth: 2.5 }),
    React.createElement("circle", { cx: 12, cy: 12, r: 9, fill: "none", stroke: "var(--color-accent)", strokeWidth: 2.5, strokeLinecap: "round", strokeDasharray: "16 40" },
      React.createElement("animateTransform", { attributeName: "transform", type: "rotate", from: "0 12 12", to: "360 12 12", dur: "0.9s", repeatCount: "indefinite" })));
}