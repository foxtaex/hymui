Icon-only button; `label` is mandatory (becomes aria-label + tooltip).
```jsx
<HmIconButton label="Search"><HmIcon name="search" /></HmIconButton>
```
Vue API: props { label (required), size, active, disabled }, emits ["click"], slot: default (icon).