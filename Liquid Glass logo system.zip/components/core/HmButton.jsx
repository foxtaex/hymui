import React from "react";
const sizes = { sm: ["var(--size-control-sm)", "0 14px", "13px"], md: ["var(--size-control-md)", "0 18px", "14px"], lg: ["var(--size-control-lg)", "0 24px", "14.5px"] };
export function HmButton({ variant = "primary", size = "md", disabled, loading, iconLeft, children, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const [h, pad, fs] = sizes[size] || sizes.md;
  const variants = {
    primary: { background: "var(--hm-accent-gradient)", color: "var(--color-on-accent)", border: "none", boxShadow: "var(--shadow-accent), inset 0 1px 0 rgba(255,255,255,0.35)", fontWeight: 700, filter: hover ? "brightness(1.07)" : "none" },
    secondary: { background: hover ? "var(--color-surface-elevated)" : "var(--color-surface)", color: "var(--color-text)", border: "1px solid var(--color-border-strong)", fontWeight: 600 },
    quiet: { background: hover ? "var(--color-accent-tint)" : "transparent", color: "var(--color-accent)", border: "none", fontWeight: 600 },
    danger: { background: hover ? "var(--color-danger-tint)" : "transparent", color: "var(--color-danger)", border: "1px solid var(--color-danger-tint)", fontWeight: 600 }
  };
  return React.createElement("button", {
    onClick, disabled: disabled || loading,
    onMouseEnter: () => setHover(true), onMouseLeave: () => { setHover(false); setPress(false); },
    onMouseDown: () => setPress(true), onMouseUp: () => setPress(false),
    style: {
      display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8,
      height: h, padding: pad, borderRadius: "var(--radius-md)", fontFamily: "var(--font-sans)", fontSize: fs,
      cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.45 : 1,
      transform: press ? "scale(0.98)" : "none",
      transition: "all var(--motion-fast) var(--ease-out)",
      ...variants[variant], ...style
    }
  }, loading ? "…" : iconLeft, children);
}