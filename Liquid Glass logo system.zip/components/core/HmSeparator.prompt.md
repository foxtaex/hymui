Divider. Inside connected glass controls use the dot variant — it echoes the logo core.
```jsx
<HmSeparator dot />
<HmSeparator vertical length={20} />
```
Vue API: props { vertical, dot, length }.