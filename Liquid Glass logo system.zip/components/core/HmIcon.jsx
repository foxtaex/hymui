import React from "react";
// Lucide via CSS mask so glyphs take currentColor. Substituted set — flag in readme.
export function HmIcon({ name, size = 16, style }) {
  return React.createElement("span", {
    "aria-hidden": true,
    style: {
      display: "inline-block", width: size, height: size, flex: "none",
      backgroundColor: "currentColor",
      WebkitMaskImage: `url(https://unpkg.com/lucide-static@0.462.0/icons/${name}.svg)`,
      maskImage: `url(https://unpkg.com/lucide-static@0.462.0/icons/${name}.svg)`,
      WebkitMaskSize: "contain", maskSize: "contain",
      WebkitMaskRepeat: "no-repeat", maskRepeat: "no-repeat",
      WebkitMaskPosition: "center", maskPosition: "center", ...style
    }
  });
}