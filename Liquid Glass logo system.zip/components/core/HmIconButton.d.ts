/** Icon-only button on solid surfaces; label is required for accessibility. */
export interface HmIconButtonProps {
  label: string;
  size?: "sm" | "md" | "lg";
  active?: boolean;
  disabled?: boolean;
  children?: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export declare function HmIconButton(props: HmIconButtonProps): JSX.Element;