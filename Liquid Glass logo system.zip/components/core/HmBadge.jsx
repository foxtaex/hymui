import React from "react";
export function HmBadge({ tone = "neutral", mono, children, style }) {
  const tones = {
    neutral: ["var(--color-surface-elevated)", "var(--color-text-muted)", "var(--color-border)"],
    accent: ["var(--color-accent-tint)", "var(--color-accent)", "rgba(15,191,174,0.3)"],
    success: ["var(--color-success-tint)", "var(--color-success)", "transparent"],
    warning: ["var(--color-warning-tint)", "var(--color-warning)", "transparent"],
    danger: ["var(--color-danger-tint)", "var(--color-danger)", "transparent"]
  };
  const [bg, fg, bd] = tones[tone] || tones.neutral;
  return React.createElement("span", {
    style: {
      display: "inline-flex", alignItems: "center", gap: 6, padding: "3px 10px",
      borderRadius: "var(--radius-full)", background: bg, color: fg, border: `1px solid ${bd}`,
      fontFamily: mono ? "var(--font-mono)" : "var(--font-sans)",
      fontSize: mono ? 11 : 12, fontWeight: mono ? 500 : 600,
      letterSpacing: mono ? "0.06em" : 0, textTransform: mono ? "uppercase" : "none", ...style
    }
  }, children);
}