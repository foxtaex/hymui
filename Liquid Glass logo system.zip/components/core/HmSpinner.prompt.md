Loading arc; pair with a text label for screen readers when inline.
```jsx
<HmSpinner size={18} />
```
Vue API: props { size }.