/** Loading placeholder block. */
export interface HmSkeletonProps { width?: number | string; height?: number | string; radius?: number; style?: React.CSSProperties; }
export declare function HmSkeleton(props: HmSkeletonProps): JSX.Element;