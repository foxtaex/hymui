Status/label pill. Use mono for machine states (AGENT RUNNING), sans for human labels (Due Friday).
```jsx
<HmBadge tone="accent" mono>agent running</HmBadge>
```
Vue API: props { tone, mono }, slot: default.