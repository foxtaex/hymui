/** Keycap row for shortcut hints. */
export interface HmKeyboardShortcutProps { keys: string[]; style?: React.CSSProperties; }
export declare function HmKeyboardShortcut(props: HmKeyboardShortcutProps): JSX.Element;