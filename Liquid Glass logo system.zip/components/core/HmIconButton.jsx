import React from "react";
const sz = { sm: 28, md: 36, lg: 44 };
export function HmIconButton({ label, size = "md", active, disabled, children, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const s = sz[size] || 36;
  return React.createElement("button", {
    "aria-label": label, title: label, onClick, disabled,
    onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
    style: {
      width: s, height: s, display: "inline-flex", alignItems: "center", justifyContent: "center",
      borderRadius: "var(--radius-md)", border: "none", cursor: disabled ? "not-allowed" : "pointer",
      background: active ? "var(--color-accent-tint)" : hover ? "var(--color-surface-elevated)" : "transparent",
      color: active ? "var(--color-accent)" : hover ? "var(--color-text)" : "var(--color-text-muted)",
      opacity: disabled ? 0.45 : 1, transition: "all var(--motion-fast) var(--ease-out)", ...style
    }
  }, children);
}