Shimmer placeholder; match the shape of the content it stands in for.
```jsx
<HmSkeleton width="60%" height={14} />
```
Vue API: props { width, height, radius }.