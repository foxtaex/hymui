Lucide icon wrapper — 1.5px stroke set matching the Hymui mark geometry. Sizes: 14/16/20/24.
```jsx
<HmIcon name="calendar" size={16} />
```
Vue API: props { name, size }. Never mix icon sets; brand states use the hy-mark-line SVG instead.