/** Hairline divider; dot=true renders the brand central-dot separator used inside Liquid Bars. */
export interface HmSeparatorProps { vertical?: boolean; dot?: boolean; length?: number | string; style?: React.CSSProperties; }
export declare function HmSeparator(props: HmSeparatorProps): JSX.Element;