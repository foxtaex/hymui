Progress for project completion, agent budgets, uploads.
```jsx
<HmProgress value={72} label="Tasks done" />
```
Vue API: props { value, max, label }.