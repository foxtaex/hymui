/** Standard opaque action button. Use HmLiquidButton on glass surfaces.
 * @startingPoint section="Primitives" subtitle="Primary, secondary, quiet, danger buttons" viewport="700x220"
 */
export interface HmButtonProps {
  variant?: "primary" | "secondary" | "quiet" | "danger";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  loading?: boolean;
  iconLeft?: React.ReactNode;
  children?: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export declare function HmButton(props: HmButtonProps): JSX.Element;