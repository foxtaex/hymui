/** Lucide glyph sized to the icon scale, colored by currentColor. */
export interface HmIconProps {
  name: string; /* lucide icon name, e.g. "search", "calendar", "bot" */
  size?: number;
  style?: React.CSSProperties;
}
export declare function HmIcon(props: HmIconProps): JSX.Element;