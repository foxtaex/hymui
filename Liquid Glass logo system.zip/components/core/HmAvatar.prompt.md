Identity chip: uploaded image, generated initials, or the Hymui line mark for agents.
```jsx
<HmAvatar name="Mara Ellis" size={32} />
<HmAvatar agent name="Scout" />
```
Vue API: props { name, src, size, agent }.