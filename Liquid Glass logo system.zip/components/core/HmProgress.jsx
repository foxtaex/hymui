import React from "react";
export function HmProgress({ value = 0, max = 100, height = 6, label, style }) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 6, ...style } },
    label && React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 12, color: "var(--color-text-muted)", fontFamily: "var(--font-sans)" } },
      React.createElement("span", null, label),
      React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 11 } }, Math.round(pct) + "%")),
    React.createElement("div", { role: "progressbar", "aria-valuenow": value, "aria-valuemax": max, style: { height, borderRadius: height / 2, background: "var(--color-border)", overflow: "hidden" } },
      React.createElement("div", { style: { width: pct + "%", height: "100%", borderRadius: height / 2, background: "var(--hm-accent-gradient)", transition: "width var(--motion-soft) var(--ease-out)" } })));
}