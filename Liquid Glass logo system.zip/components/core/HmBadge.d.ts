/** Status pill. mono=true renders the metadata style (uppercase Plex Mono). */
export interface HmBadgeProps {
  tone?: "neutral" | "accent" | "success" | "warning" | "danger";
  mono?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function HmBadge(props: HmBadgeProps): JSX.Element;