Keycaps in menus, tooltips, command palette.
```jsx
<HmKeyboardShortcut keys={["⌘", "K"]} />
```
Vue API: props { keys: string[] }.