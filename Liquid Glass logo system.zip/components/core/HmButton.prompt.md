Opaque action button on solid surfaces; one primary per view.
```jsx
<HmButton variant="primary" onClick={save}>Approve</HmButton>
<HmButton variant="quiet" size="sm">Review diff</HmButton>
```
Variants: primary (mint→green gradient, dark text), secondary, quiet, danger (destructive intent — confirmation still goes through HmConfirmDialog).
Vue API: props { variant, size, disabled, loading }, emits ["click"], slots: default, icon.