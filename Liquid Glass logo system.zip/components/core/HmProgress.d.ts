/** Determinate progress bar with the accent gradient fill. */
export interface HmProgressProps { value?: number; max?: number; height?: number; label?: string; style?: React.CSSProperties; }
export declare function HmProgress(props: HmProgressProps): JSX.Element;