import React from "react";
export function HmSeparator({ vertical, dot, length, style }) {
  if (dot) return React.createElement("span", { "aria-hidden": true, style: { width: 4, height: 4, borderRadius: "50%", background: "var(--hm-mint-subtle)", opacity: 0.6, flex: "none", ...style } });
  return React.createElement("span", { "aria-hidden": true, style: vertical
    ? { width: 1, height: length || 20, background: "var(--color-border)", flex: "none", ...style }
    : { display: "block", height: 1, width: length || "100%", background: "var(--color-border)", ...style } });
}