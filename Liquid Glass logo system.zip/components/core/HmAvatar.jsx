import React from "react";
export function HmAvatar({ name = "", src, size = 32, agent, style }) {
  const initials = name.split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();
  const base = {
    width: size, height: size, borderRadius: size * 0.36, flex: "none",
    display: "inline-flex", alignItems: "center", justifyContent: "center", overflow: "hidden",
    border: "1px solid var(--color-border)", ...style
  };
  if (src) return React.createElement("span", { style: base }, React.createElement("img", { src, alt: name, style: { width: "100%", height: "100%", objectFit: "cover" } }));
  if (agent) return React.createElement("span", { style: { ...base, background: "var(--color-accent-tint)", color: "var(--color-accent)" } },
    React.createElement("svg", { viewBox: "0 0 72 72", style: { width: size * 0.62, height: size * 0.62 } },
      React.createElement("g", { fill: "none", stroke: "currentColor", strokeWidth: 4.5, strokeLinecap: "round", strokeLinejoin: "round" },
        React.createElement("path", { d: "M16 28 L16 16 L36 16" }),
        React.createElement("path", { d: "M16 28 L16 16 L36 16", transform: "rotate(90 36 36)" }),
        React.createElement("path", { d: "M16 28 L16 16 L36 16", transform: "rotate(180 36 36)" }),
        React.createElement("path", { d: "M16 28 L16 16 L36 16", transform: "rotate(270 36 36)" })),
      React.createElement("circle", { cx: 36, cy: 36, r: 4, fill: "currentColor" })));
  return React.createElement("span", { style: { ...base, background: "var(--color-surface-elevated)", color: "var(--color-text-muted)", fontSize: size * 0.36, fontWeight: 600, fontFamily: "var(--font-sans)" } }, initials || "?");
}