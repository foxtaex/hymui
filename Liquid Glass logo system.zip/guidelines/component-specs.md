# Component specifications — product families

Reference implementations for the foundation families live in `components/` (each with `.d.ts` + `.prompt.md`). The product-level families below are specified here and demonstrated in `ui_kits/hymui/`; all compose the Hm primitives — **no component implements its own glass**.

Conventions for every component: typed props + events, slots for content, sizes sm/md/lg where meaningful, all states (default/hover/focus-visible/active/selected/disabled/loading/error/offline/conflict/permission-denied), full keyboard support, 44px touch targets, AA contrast, longer-translation-safe labels, 200% zoom safe.

## Layout
- **AppShell** — top Liquid Bar + content region + optional Liquid Panels. Props `{ nav: NavItem[], active }`, emits `navigate`, slots `bar-leading/bar-trailing/default`. Mobile (<640px): bar becomes bottom Liquid Bar, panels become HmDrawer.
- **PageHeader** — mono breadcrumb line + page title + actions slot. **Breadcrumbs**: `items: {label, to}[]`, separated by `HmSeparator dot`.
- **Tabs** — HmLiquidControlGroup when floating over content; underline style on solid surfaces. Props `{ items, modelValue }`, emits `update:modelValue`.
- **SplitView / AdjustablePanels** — CSS grid + 6px drag handles (keyboard: arrow keys resize by 8px). Persist widths per user. **InspectorPanel** = right HmLiquidPanel `width: var(--inspector-width)`.
- **Toolbar** = HmLiquidBar `floating=false`. **StatusBar** — solid hairline strip, mono metadata (sync state, peer count).

## Projects (home)
- **ProjectWorkspace** — grid of ProjectCards + folder rows (one folder level). `ui_kits/hymui/ProjectsHome.jsx`.
- **ProjectCard** — solid surface; name, description, HmProgress, member HmAvatars, mono content summary, optional RepositoryLink + agent badge. Props `{ project }`, emits `open`. Hover: mint border + 2px lift.
- **ProjectTree / ProjectFolder / ProjectItem** — sidebar tree, one nesting level; items show type icon (HmIcon: kanban / file-text / calendar / frame / bot).
- **ProjectLink / RepositoryLink** — mono chip `git · owner/repo`, opens external; RepositoryLink shows sync state dot.
- **ProjectMembers** — overlapping avatars, +N overflow popover.

## Board
- **BoardView / BoardToolbar** — toolbar = HmLiquidControlGroup (Board/Timeline/Table) + filter/search/settings icon cluster. `BoardView.jsx`.
- **BoardColumn** — mono uppercase header `TITLE · count`, add button; sortable (drag or ⌘←→). **ArchiveColumn** — collapsed dashed rail; restore flow asks target board (restored cards show originating board).
- **CardItem** — solid `--color-surface-elevated`; labels → title → meta row (assignee, due, checklist count, doc chip). Agent-proposed: mint border + `PROPOSED BY <AGENT>` mono line. Keyboard drag: Space lifts, arrows move, Space drops, Esc cancels.
- **CardDetails** — HmDrawer. **CardChecklist** — task list rows. **CardAttachment / CardDocReference** — description mode (doc title + rendered content become the description) or attachment mode (docs icon + real doc title; never placeholder titles).
- **BoardFilter** — HmPopover of HmCheckboxes. **BoardSettings** — HmDialog.

## Docs
- **DocsEditor** — modes Write / Preview / Split / Reverse Split via HmLiquidControlGroup; one shared document state, scroll-synced. Editor + preview are solid surfaces at `--container-content` measure. `DocsWorkspace.jsx`.
- **MarkdownToolbar** — HmLiquidBar `floating=false`: bold/italic/heading/list/task/link/image/quote/table/code; groups split by `HmSeparator dot`.
- **DocsSidebar** — HmLiquidPanel tree; conflict dot on files needing merge. **DocsTitleEditor** — borderless inline input. **DocsHistory** — HmDrawer with version list. **DocsConflictView** — side-by-side versions + HmConflictState header; actions: keep A / keep B / merge.

## Planner
- **PlannerView** — Agenda/Week/Month/Day/Timeline via HmLiquidControlGroup. `PlannerView.jsx`.
- **PlannerItem** — time+tz column · title · project · `PlannerSourceBadge` (mono type badge: Project / Board card / Event / Milestone) · source link (arrow-up-right) · assignee. Type is always shown in words, never only color.
- **MilestoneItem** — diamond marker, success tone. **EventDialog** — HmDialog with date/time/tz fields. **PlannerFilters** — source checkboxes with color keys.

## Whiteboard
- **WhiteboardCanvas** — solid dotted-grid surface; objects (sticky notes, shapes, text, images, frames) are fully opaque; no backdrop filters on canvas content (performance). Glass floats above only: creation toolbar (vertical HmLiquidBar), zoom bar, minimap (HmLiquidSurface panel), inspector (HmLiquidPanel), selection actions (small HmLiquidBar), style popovers. `WhiteboardView.jsx`.
- **WhiteboardNode / Connector / Frame / Selection / Comment** — connectors are 2px `--hm-mint-subtle` curves with arrowheads; selection = 1.5px mint outline + 8px handles; frames have mono labels above the border.
- **WhiteboardEmbed** — live references: Doc (title + content preview), Board card (status, board, assignees, due), Planner item (type, date, source), Project (progress). Linked, never copied; `LIVE` mono tag.
- Export PNG/SVG/PDF from the toolbar overflow.

## AI Agents
- **AgentRunPanel** — profile header (HmAvatar agent) + status badge + budget HmProgress; timeline rail; proposal cards; approval row. `AgentReview.jsx`.
- Statuses (HmBadge, always worded): draft (neutral) / proposed (accent) / waiting for approval (warning) / approved (success) / running (accent mono + pulsing center dot) / paused (neutral) / completed (success) / failed (danger) / cancelled (neutral).
- **AgentProposal** — mint-bordered card: icon well, title, kind badge, plain-language description, View diff. Proposed content is held outside the project until approved. **AgentApproval** — HmConfirmDialog (Focus level) naming exact scope of change. **AgentScope / AgentToolList** — mono `boards.read`-style entries. **AgentHistory / AgentArtifact** — run list with outcomes and produced items.

## Settings
- **Settings\*** — HmLiquidPanel nav + solid form card per section (`SettingsView.jsx`). All dropdowns are HmSelect/HmCombobox — never native. **AvatarSettings** — upload / Hymui icon / initials. **AppearanceSettings** — theme radio (dark/light/system), reduced transparency, reduced motion, pointer highlights. **FederationSettings** — peer rows with worded status badges.
