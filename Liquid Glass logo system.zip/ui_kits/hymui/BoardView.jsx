window.HmKit = window.HmKit || {};
window.HmKit.BoardView = function BoardView({ K }) {
  const { HmLiquidControlGroup, HmLiquidBar, HmLiquidIconButton, HmBadge, HmAvatar, HmIcon, HmSeparator, HmPopover, HmCheckbox } = K;
  const [view, setView] = React.useState("board");
  const [filterOpen, setFilterOpen] = React.useState(false);
  const cols = [
    { title: "Planned", n: 3, cards: [
      { t: "Order seed stock for spring beds", labels: [["Purchasing", "neutral"]], who: "Priya Nair", due: "Mar 4", check: "0/4" },
      { t: "Volunteer day sign-up sheet", labels: [["Community", "accent"]], who: "Mara Ellis", doc: "Volunteer guide" },
      { t: "Plot allocation rules v2", labels: [["Docs", "neutral"]], who: "Jon Ade", doc: "Allocation rules" }] },
    { title: "In progress", n: 2, cards: [
      { t: "Compost workshop planning", labels: [["Event", "accent"]], who: "Mara Ellis", due: "Feb 28", check: "3/6" },
      { t: "Irrigation quote comparison", labels: [["Purchasing", "neutral"]], who: "Sam Ortiz", agent: true }] },
    { title: "Review", n: 1, cards: [
      { t: "Grant application draft", labels: [["Funding", "warning"]], who: "Priya Nair", due: "Mar 1", doc: "Grant draft" }] },
    { title: "Done", n: 2, dim: true, cards: [
      { t: "Winter bed cover install", who: "Jon Ade" },
      { t: "Tool shed inventory", who: "Mara Ellis" }] }
  ];
  return <div style={{height:"100%", display:"flex", flexDirection:"column", padding:"10px 28px 24px", boxSizing:"border-box", gap:14}}>
    <div style={{display:"flex", alignItems:"center", gap:14, justifyContent:"space-between"}}>
      <div>
        <div style={{fontFamily:"var(--font-mono)", fontSize:10.5, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)"}}>Riverside Community Garden</div>
        <div style={{fontSize:19, fontWeight:600, marginTop:2}}>Spring planting</div>
      </div>
      <div style={{display:"flex", alignItems:"center", gap:12, position:"relative"}}>
        <HmLiquidControlGroup items={[{value:"board",label:"Board"},{value:"timeline",label:"Timeline"},{value:"table",label:"Table"}]} value={view} onChange={setView} />
        <HmLiquidBar floating={false} style={{padding:"5px 8px"}}>
          <HmLiquidIconButton label="Filter" active={filterOpen} onClick={() => setFilterOpen(!filterOpen)}><HmIcon name="list-filter" size={16} /></HmLiquidIconButton>
          <HmLiquidIconButton label="Search cards"><HmIcon name="search" size={16} /></HmLiquidIconButton>
          <HmSeparator dot />
          <HmLiquidIconButton label="Board settings"><HmIcon name="settings-2" size={16} /></HmLiquidIconButton>
        </HmLiquidBar>
        <div style={{position:"absolute", top:"calc(100% + 8px)", right:0, zIndex:"var(--z-overlay)"}}>
          <HmPopover open={filterOpen} title="Show only" origin="top right">
            <div style={{display:"flex", flexDirection:"column", gap:10, padding:"0 2px 4px"}}>
              <HmCheckbox label="Assigned to me" checked />
              <HmCheckbox label="Agent-created" />
              <HmCheckbox label="Due this week" />
            </div>
          </HmPopover>
        </div>
      </div>
    </div>
    <div style={{flex:1, minHeight:0, display:"grid", gridTemplateColumns:"repeat(4, 1fr) 44px", gap:14}}>
      {cols.map((c, i) => <div key={i} style={{display:"flex", flexDirection:"column", gap:10, minHeight:0, opacity:c.dim ? 0.75 : 1}}>
        <div style={{display:"flex", alignItems:"center", gap:8, padding:"0 4px"}}>
          <span style={{fontFamily:"var(--font-mono)", fontSize:10.5, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)"}}>{c.title} · {c.n}</span>
          <span style={{marginLeft:"auto", cursor:"pointer", display:"inline-flex"}}><HmIcon name="plus" size={14} style={{color:"var(--color-text-faint)"}} /></span>
        </div>
        <div style={{display:"flex", flexDirection:"column", gap:8, overflowY:"auto", paddingBottom:8}}>
          {c.cards.map((card, j) => <div key={j} tabIndex={0} style={{
            background:"var(--color-surface-elevated)", borderRadius:"var(--radius-lg)", padding:"13px 15px",
            border: card.agent ? "1px solid rgba(15,191,174,0.35)" : "1px solid var(--color-border)",
            display:"flex", flexDirection:"column", gap:9, cursor:"grab"}}>
            {card.labels && <div style={{display:"flex", gap:6}}>{card.labels.map(([l, tone], x) => <HmBadge key={x} tone={tone} style={{fontSize:11, padding:"2px 8px"}}>{l}</HmBadge>)}</div>}
            <div style={{fontSize:13.5, fontWeight:600, lineHeight:1.4}}>{card.t}</div>
            {card.agent && <div style={{display:"flex", alignItems:"center", gap:6}}><HmAvatar agent name="Scout" size={18} /><span style={{fontFamily:"var(--font-mono)", fontSize:10, color:"var(--color-accent)", letterSpacing:"0.06em"}}>PROPOSED BY SCOUT</span></div>}
            <div style={{display:"flex", alignItems:"center", gap:8}}>
              <HmAvatar name={card.who} size={20} />
              {card.due && <span style={{display:"inline-flex", alignItems:"center", gap:4, fontSize:11.5, color:"var(--color-text-muted)"}}><HmIcon name="calendar" size={12} />{card.due}</span>}
              {card.check && <span style={{display:"inline-flex", alignItems:"center", gap:4, fontSize:11.5, color:"var(--color-text-muted)"}}><HmIcon name="square-check" size={12} />{card.check}</span>}
              {card.doc && <span style={{display:"inline-flex", alignItems:"center", gap:4, fontSize:11.5, color:"var(--hm-mint-subtle)", marginLeft:"auto"}}><HmIcon name="file-text" size={12} />{card.doc}</span>}
            </div>
          </div>)}
        </div>
      </div>)}
      <div style={{writingMode:"vertical-rl", display:"flex", alignItems:"center", gap:8, padding:"10px 0", borderRadius:"var(--radius-lg)", border:"1px dashed var(--color-border-strong)", color:"var(--color-text-faint)", fontFamily:"var(--font-mono)", fontSize:10.5, letterSpacing:"0.12em", textTransform:"uppercase", justifyContent:"center", cursor:"pointer"}}>Archive</div>
    </div>
  </div>;
};