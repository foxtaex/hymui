window.HmKit = window.HmKit || {};
window.HmKit.DocsWorkspace = function DocsWorkspace({ K }) {
  const { HmLiquidPanel, HmLiquidControlGroup, HmLiquidIconButton, HmIcon, HmBadge, HmSeparator } = K;
  const [mode, setMode] = React.useState("split");
  const docs = [
    { t: "Volunteer guide", active: true }, { t: "Allocation rules" }, { t: "Grant draft", badge: "conflict" },
    { t: "Compost workshop notes" }, { t: "Season retrospective" }
  ];
  const src = [
    "# Volunteer guide", "", "Welcome to the Riverside Community Garden.", "",
    "## Before your first day", "", "- [x] Sign the plot agreement", "- [x] Pick up a gate key from Mara",
    "- [ ] Join the #volunteers channel", "", "## Watering schedule", "",
    "| Day | Beds | Lead |", "| --- | --- | --- |", "| Tue | 1–8 | Jon |", "| Sat | 9–16 | Priya |",
    "", "\`\`\`js", "// gate code rotates monthly", "const code = rotate(seed, month);", "\`\`\`"
  ];
  return <div style={{height:"100%", display:"flex", gap:16, padding:"10px 24px 24px", boxSizing:"border-box"}}>
    <HmLiquidPanel width={240} style={{flex:"none", overflowY:"auto"}}>
      <div style={{fontFamily:"var(--font-mono)", fontSize:10, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)", padding:"4px 10px 10px"}}>Docs · Riverside Garden</div>
      {docs.map((d, i) => <div key={i} style={{
        display:"flex", alignItems:"center", gap:9, padding:"9px 10px", borderRadius:"var(--radius-sm)",
        background: d.active ? "var(--color-accent-tint)" : "transparent",
        color: d.active ? "var(--color-text)" : "var(--color-text-muted)",
        fontSize:13.5, fontWeight: d.active ? 600 : 500, cursor:"pointer"}}>
        <HmIcon name="file-text" size={14} style={{opacity:0.7}} />
        <span style={{flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}}>{d.t}</span>
        {d.badge && <span style={{width:6, height:6, borderRadius:"50%", background:"var(--color-warning)"}} title="Sync conflict" />}
      </div>)}
    </HmLiquidPanel>
    <div style={{flex:1, minWidth:0, display:"flex", flexDirection:"column", gap:12}}>
      <div style={{display:"flex", alignItems:"center", justifyContent:"space-between", gap:14}}>
        <input defaultValue="Volunteer guide" aria-label="Doc title" style={{fontSize:19, fontWeight:600, fontFamily:"var(--font-sans)", background:"transparent", border:"none", outline:"none", color:"var(--color-text)", flex:1, minWidth:0}} />
        <div style={{display:"flex", alignItems:"center", gap:10}}>
          <HmBadge mono>saved · local</HmBadge>
          <HmLiquidControlGroup items={[{value:"write",label:"Write"},{value:"split",label:"Split"},{value:"preview",label:"Preview"}]} value={mode} onChange={setMode} />
          <HmLiquidIconButton label="History"><HmIcon name="history" size={16} /></HmLiquidIconButton>
          <HmLiquidIconButton label="Export"><HmIcon name="download" size={16} /></HmLiquidIconButton>
        </div>
      </div>
      <div style={{flex:1, minHeight:0, display:"grid", gridTemplateColumns: mode === "split" ? "1fr 1fr" : "1fr", gap:14}}>
        {(mode === "write" || mode === "split") && <div style={{background:"var(--color-surface-solid)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-lg)", padding:"20px 24px", overflowY:"auto", fontFamily:"var(--font-mono)", fontSize:"var(--text-code-size)", lineHeight:"var(--text-code-line)", color:"var(--color-text-muted)", whiteSpace:"pre-wrap"}}>{src.join("\n")}</div>}
        {(mode === "preview" || mode === "split") && <div style={{background:"var(--color-surface-solid)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-lg)", padding:"22px 28px", overflowY:"auto", maxWidth: mode === "preview" ? "var(--container-content)" : "none", margin: mode === "preview" ? "0 auto" : 0, width:"100%", boxSizing:"border-box"}}>
          <h2 style={{margin:"0 0 12px", fontSize:22, fontWeight:600, letterSpacing:"-0.02em"}}>Volunteer guide</h2>
          <p style={{margin:"0 0 16px", fontSize:14.5, lineHeight:1.65, color:"var(--color-text-muted)"}}>Welcome to the Riverside Community Garden.</p>
          <h3 style={{margin:"0 0 10px", fontSize:16, fontWeight:600}}>Before your first day</h3>
          <div style={{display:"flex", flexDirection:"column", gap:7, marginBottom:18}}>
            {[["Sign the plot agreement", true], ["Pick up a gate key from Mara", true], ["Join the #volunteers channel", false]].map(([t, done], i) =>
              <label key={i} style={{display:"flex", alignItems:"center", gap:9, fontSize:14, color: done ? "var(--color-text-faint)" : "var(--color-text)", textDecoration: done ? "line-through" : "none"}}>
                <span style={{width:15, height:15, borderRadius:5, display:"inline-flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:700, background: done ? "var(--hm-accent-gradient)" : "transparent", border: done ? "none" : "1.5px solid var(--color-border-strong)", color:"var(--color-on-accent)"}}>{done ? "✓" : ""}</span>{t}
              </label>)}
          </div>
          <h3 style={{margin:"0 0 10px", fontSize:16, fontWeight:600}}>Watering schedule</h3>
          <table style={{borderCollapse:"collapse", fontSize:13.5, marginBottom:18}}>
            <thead><tr>{["Day","Beds","Lead"].map(h => <th key={h} style={{textAlign:"left", padding:"7px 18px 7px 0", borderBottom:"1px solid var(--color-border-strong)", fontWeight:600}}>{h}</th>)}</tr></thead>
            <tbody>{[["Tue","1–8","Jon"],["Sat","9–16","Priya"]].map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j} style={{padding:"7px 18px 7px 0", borderBottom:"1px solid var(--color-border)", color:"var(--color-text-muted)"}}>{c}</td>)}</tr>)}</tbody>
          </table>
          <pre style={{background:"var(--color-background)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-sm)", padding:"12px 16px", fontSize:12.5, lineHeight:1.6, overflow:"auto"}}><code><span style={{color:"var(--color-text-faint)"}}>// gate code rotates monthly</span>{"\n"}<span style={{color:"var(--hm-mint-subtle)"}}>const</span> code = <span style={{color:"var(--color-accent)"}}>rotate</span>(seed, month);</code></pre>
        </div>}
      </div>
    </div>
  </div>;
};