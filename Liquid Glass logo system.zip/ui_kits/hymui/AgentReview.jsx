window.HmKit = window.HmKit || {};
window.HmKit.AgentReview = function AgentReview({ K }) {
  const { HmAvatar, HmBadge, HmButton, HmProgress, HmIcon, HmSeparator, HmConfirmDialog, HmLiquidSurface } = K;
  const [confirm, setConfirm] = React.useState(false);
  const steps = [
    { t: "Read 3 boards, 14 docs", s: "done", time: "14:02" },
    { t: "Found 12 duplicate tasks across boards", s: "done", time: "14:03" },
    { t: "Drafted merge proposal", s: "done", time: "14:05" },
    { t: "Waiting for approval", s: "waiting", time: "now" }
  ];
  const proposals = [
    { kind: "Board cards", icon: "kanban", t: "Merge 12 duplicates into 5 canonical cards", d: "Across Spring planting, Infrastructure and Events. Assignees and checklists are preserved; duplicates archive with a back-link." },
    { kind: "Doc", icon: "file-text", t: "\u201CTask hygiene notes\u201D — new doc", d: "Summary of what was merged and why, linked from each canonical card." }
  ];
  return <div style={{height:"100%", overflowY:"auto", padding:"14px 40px 40px", boxSizing:"border-box", position:"relative"}}>
    <div style={{maxWidth:880, margin:"0 auto", display:"flex", flexDirection:"column", gap:18}}>
      <div style={{display:"flex", alignItems:"center", gap:16}}>
        <HmAvatar agent name="Scout" size={44} />
        <div style={{flex:1}}>
          <div style={{display:"flex", alignItems:"center", gap:10}}>
            <span style={{fontSize:19, fontWeight:600}}>Scout · task cleanup</span>
            <HmBadge tone="warning" mono>waiting for approval</HmBadge>
          </div>
          <div style={{fontSize:13, color:"var(--color-text-muted)", marginTop:2}}>Riverside Community Garden · scope: boards + docs, read-write · run 14 of 50 this month</div>
        </div>
        <div style={{width:170}}><HmProgress value={28} label="Monthly budget" /></div>
      </div>
      <div style={{display:"grid", gridTemplateColumns:"270px 1fr", gap:18, alignItems:"start"}}>
        <div style={{background:"var(--color-surface)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-2xl)", padding:"18px 20px", display:"flex", flexDirection:"column", gap:0}}>
          <div style={{fontFamily:"var(--font-mono)", fontSize:10, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)", marginBottom:12}}>Run timeline</div>
          {steps.map((s, i) => <div key={i} style={{display:"flex", gap:12, position:"relative", paddingBottom: i < steps.length - 1 ? 18 : 0}}>
            {i < steps.length - 1 && <span style={{position:"absolute", left:5.5, top:16, bottom:2, width:1, background:"var(--color-border)"}} />}
            <span style={{width:12, height:12, borderRadius:"50%", flex:"none", marginTop:3,
              background: s.s === "done" ? "var(--color-success)" : "transparent",
              border: s.s === "done" ? "none" : "2px solid var(--color-accent)",
              boxShadow: s.s === "waiting" ? "0 0 8px rgba(15,191,174,0.7)" : "none"}} />
            <div style={{flex:1}}>
              <div style={{fontSize:13, fontWeight: s.s === "waiting" ? 600 : 500, color: s.s === "waiting" ? "var(--color-text)" : "var(--color-text-muted)"}}>{s.t}</div>
              <div style={{fontFamily:"var(--font-mono)", fontSize:9.5, color:"var(--color-text-faint)", marginTop:2}}>{s.time}</div>
            </div>
          </div>)}
          <div style={{borderTop:"1px solid var(--color-border)", marginTop:16, paddingTop:14, display:"flex", flexDirection:"column", gap:8}}>
            <div style={{fontFamily:"var(--font-mono)", fontSize:10, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)"}}>Tools used</div>
            {["boards.read", "docs.read", "boards.propose"].map((t, i) => <span key={i} style={{fontFamily:"var(--font-mono)", fontSize:11.5, color:"var(--color-text-muted)"}}>{t}</span>)}
          </div>
        </div>
        <div style={{display:"flex", flexDirection:"column", gap:14}}>
          <div style={{fontSize:14, lineHeight:1.65, color:"var(--color-text-muted)", background:"var(--color-surface)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-lg)", padding:"16px 20px"}}>
            <strong style={{color:"var(--color-text)", fontWeight:600}}>Proposal.</strong> Scout will merge 12 duplicate tasks across 3 boards and create one summary doc. Nothing changes until you approve — proposed content is held outside the project.
          </div>
          {proposals.map((p, i) => <div key={i} style={{background:"var(--color-surface-elevated)", border:"1px solid rgba(15,191,174,0.25)", borderRadius:"var(--radius-lg)", padding:"16px 20px", display:"flex", gap:14}}>
            <span style={{width:34, height:34, borderRadius:12, flex:"none", background:"var(--color-accent-tint)", display:"inline-flex", alignItems:"center", justifyContent:"center", color:"var(--color-accent)"}}><HmIcon name={p.icon} size={16} /></span>
            <div style={{flex:1}}>
              <div style={{display:"flex", alignItems:"center", gap:8}}>
                <span style={{fontSize:14, fontWeight:600}}>{p.t}</span>
                <HmBadge mono>{p.kind}</HmBadge>
              </div>
              <div style={{fontSize:13, lineHeight:1.6, color:"var(--color-text-muted)", marginTop:4}}>{p.d}</div>
            </div>
            <HmButton variant="quiet" size="sm">View diff</HmButton>
          </div>)}
          <div style={{display:"flex", gap:10, justifyContent:"flex-end", paddingTop:2}}>
            <HmButton variant="secondary">Reject</HmButton>
            <HmButton variant="secondary">Edit scope</HmButton>
            <HmButton onClick={() => setConfirm(true)}>Approve all</HmButton>
          </div>
        </div>
      </div>
    </div>
    <HmConfirmDialog contain open={confirm} title="Approve agent run?"
      description="Scout will merge 12 duplicate tasks across 3 boards and add 1 doc. This edits shared project data and syncs to 7 peers."
      confirmLabel="Approve" cancelLabel="Review again"
      onConfirm={() => setConfirm(false)} onCancel={() => setConfirm(false)} />
  </div>;
};