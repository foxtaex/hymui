window.HmKit = window.HmKit || {};
window.HmKit.SettingsView = function SettingsView({ K }) {
  const { HmLiquidPanel, HmInput, HmSelect, HmSwitch, HmRadio, HmAvatar, HmButton, HmIcon, HmBadge, HmSeparator } = K;
  const [section, setSection] = React.useState("appearance");
  const [theme, setTheme] = React.useState("dark");
  const [rt, setRt] = React.useState(false);
  const [rm, setRm] = React.useState(false);
  const sections = [["profile","Profile","user"],["appearance","Appearance","sun-moon"],["language","Language","languages"],["security","Security","lock"],["workspace","Workspace","layout-grid"],["agents","Agents","bot"],["plugins","Plugins","puzzle"],["federation","Federation","share-2"],["storage","Storage","database"]];
  return <div style={{height:"100%", display:"flex", gap:20, padding:"10px 28px 24px", boxSizing:"border-box"}}>
    <HmLiquidPanel width={230} style={{flex:"none", overflowY:"auto"}}>
      <div style={{fontFamily:"var(--font-mono)", fontSize:10, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)", padding:"4px 10px 10px"}}>Settings</div>
      {sections.map(([id, label, icon]) => <div key={id} onClick={() => setSection(id)} style={{
        display:"flex", alignItems:"center", gap:10, padding:"9px 10px", borderRadius:"var(--radius-sm)",
        background: section === id ? "var(--color-accent-tint)" : "transparent",
        color: section === id ? "var(--color-text)" : "var(--color-text-muted)",
        fontSize:13.5, fontWeight: section === id ? 600 : 500, cursor:"pointer"}}>
        <HmIcon name={icon} size={15} style={{opacity:0.75}} />{label}
      </div>)}
    </HmLiquidPanel>
    <div style={{flex:1, minWidth:0, overflowY:"auto"}}>
      <div style={{maxWidth:560, display:"flex", flexDirection:"column", gap:26, background:"var(--color-surface-solid)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-2xl)", padding:"28px 32px", boxSizing:"border-box"}}>
        {section === "appearance" ? <>
          <div>
            <div style={{fontSize:17, fontWeight:600}}>Appearance</div>
            <div style={{fontSize:13, color:"var(--color-text-muted)", marginTop:3}}>Theme and material settings for this device.</div>
          </div>
          <div style={{display:"flex", flexDirection:"column", gap:8}}>
            <span style={{fontSize:13, fontWeight:600}}>Theme</span>
            <HmRadio options={[{value:"dark",label:"Dark"},{value:"light",label:"Light"},{value:"system",label:"System"}]} value={theme} onChange={setTheme} />
          </div>
          <HmSeparator />
          <div style={{display:"flex", flexDirection:"column", gap:16}}>
            <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", gap:16}}>
              <div><div style={{fontSize:14, fontWeight:600}}>Reduced transparency</div><div style={{fontSize:12.5, color:"var(--color-text-muted)", marginTop:2}}>Near-solid panels; also used automatically when blur is unsupported.</div></div>
              <HmSwitch checked={rt} onChange={setRt} />
            </div>
            <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", gap:16}}>
              <div><div style={{fontSize:14, fontWeight:600}}>Reduced motion</div><div style={{fontSize:12.5, color:"var(--color-text-muted)", marginTop:2}}>Turns spring animations into instant changes.</div></div>
              <HmSwitch checked={rm} onChange={setRm} />
            </div>
            <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", gap:16}}>
              <div><div style={{fontSize:14, fontWeight:600}}>Pointer highlights</div><div style={{fontSize:12.5, color:"var(--color-text-muted)", marginTop:2}}>Specular sheen on glass; off on low-power devices.</div></div>
              <HmSwitch checked />
            </div>
          </div>
        </> : section === "profile" ? <>
          <div>
            <div style={{fontSize:17, fontWeight:600}}>Profile</div>
            <div style={{fontSize:13, color:"var(--color-text-muted)", marginTop:3}}>How you appear to collaborators and federated peers.</div>
          </div>
          <div style={{display:"flex", alignItems:"center", gap:16}}>
            <HmAvatar name="Mara Ellis" size={56} />
            <div style={{display:"flex", gap:8}}>
              <HmButton variant="secondary" size="sm">Upload image</HmButton>
              <HmButton variant="quiet" size="sm">Use Hymui icon</HmButton>
              <HmButton variant="quiet" size="sm">Use initials</HmButton>
            </div>
          </div>
          <HmInput label="Display name" defaultValue="Mara Ellis" />
          <HmInput label="Instance handle" defaultValue="mara@studio-north" hint="Visible to federated peers" />
        </> : section === "federation" ? <>
          <div>
            <div style={{fontSize:17, fontWeight:600}}>Federation</div>
            <div style={{fontSize:13, color:"var(--color-text-muted)", marginTop:3}}>Peers this instance syncs with.</div>
          </div>
          <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", gap:16}}>
            <div><div style={{fontSize:14, fontWeight:600}}>Federation</div><div style={{fontSize:12.5, color:"var(--color-text-muted)", marginTop:2}}>Share selected projects with trusted peers.</div></div>
            <HmSwitch checked />
          </div>
          {[["riverside.coop", "connected", "success"], ["jon.local", "connected", "success"], ["gallery-hub.net", "pending invite", "warning"]].map(([peer, s, tone], i) =>
            <div key={i} style={{display:"flex", alignItems:"center", gap:12, padding:"12px 14px", border:"1px solid var(--color-border)", borderRadius:"var(--radius-md)"}}>
              <span style={{fontFamily:"var(--font-mono)", fontSize:13, flex:1}}>{peer}</span>
              <HmBadge tone={tone} mono>{s}</HmBadge>
              <HmButton variant="quiet" size="sm">Manage</HmButton>
            </div>)}
        </> : <>
          <div>
            <div style={{fontSize:17, fontWeight:600}}>{sections.find(s => s[0] === section)[1]}</div>
            <div style={{fontSize:13, color:"var(--color-text-muted)", marginTop:3}}>Example content omitted in this kit — composes the same form primitives.</div>
          </div>
        </>}
      </div>
    </div>
  </div>;
};