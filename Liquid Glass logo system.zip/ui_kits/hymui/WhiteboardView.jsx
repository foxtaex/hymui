window.HmKit = window.HmKit || {};
window.HmKit.WhiteboardView = function WhiteboardView({ K }) {
  const { HmLiquidBar, HmLiquidIconButton, HmLiquidSurface, HmIcon, HmSeparator, HmBadge, HmAvatar, HmSlider } = K;
  const [tool, setTool] = React.useState("select");
  const tools = [["select","mouse-pointer-2"],["hand","hand"],["sticky","sticky-note"],["shape","square"],["connector","spline"],["pen","pen-tool"],["text","type"],["frame","frame"]];
  return <div style={{height:"100%", position:"relative", overflow:"hidden", margin:"6px 24px 24px", borderRadius:"var(--radius-2xl)", border:"1px solid var(--color-border)",
    background:"radial-gradient(circle, var(--color-border) 1px, transparent 1px) 0 0 / 26px 26px, var(--color-surface)"}}>
    {/* canvas objects — solid, calm */}
    <div style={{position:"absolute", left:70, top:60, width:420, height:280, borderRadius:18, border:"1.5px solid var(--color-border-strong)", background:"rgba(20,26,25,0.35)"}}>
      <div style={{position:"absolute", top:-24, left:6, fontFamily:"var(--font-mono)", fontSize:10.5, letterSpacing:"0.1em", textTransform:"uppercase", color:"var(--color-text-faint)"}}>Frame · Garden layout</div>
    </div>
    {[["Beds 1–8\nsun, tomatoes", 110, 100, "#B8DED2", 0], ["Beds 9–16\npartial shade", 300, 100, "#EFE3B8", -1.5], ["Compost\ncorner", 110, 230, "#D8C9EE", 1]].map(([t, x, y, c, r], i) =>
      <div key={i} style={{position:"absolute", left:x, top:y, width:150, height:100, background:c, borderRadius:6, padding:"12px 14px", boxSizing:"border-box",
        fontSize:13, fontWeight:600, lineHeight:1.45, color:"#2A2F2D", whiteSpace:"pre-line",
        boxShadow:"0 8px 20px rgba(0,0,0,0.3)", transform:`rotate(${r}deg)`}}>{t}</div>)}
    <svg style={{position:"absolute", left:0, top:0, width:"100%", height:"100%", pointerEvents:"none"}}>
      <path d="M 545 210 C 610 210, 610 170, 660 170" fill="none" stroke="var(--hm-mint-subtle)" strokeWidth="2" strokeDasharray="0" markerEnd="url(#arr)" />
      <defs><marker id="arr" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 L10 5 L0 10 z" fill="var(--hm-mint-subtle)" /></marker></defs>
    </svg>
    {/* live board-card embed */}
    <div style={{position:"absolute", left:660, top:120, width:250, background:"var(--color-surface-elevated)", border:"1px solid rgba(15,191,174,0.3)", borderRadius:14, padding:"13px 15px", boxShadow:"var(--shadow-2)"}}>
      <div style={{display:"flex", alignItems:"center", gap:6, marginBottom:7}}>
        <HmIcon name="kanban" size={12} style={{color:"var(--hm-mint-subtle)"}} />
        <span style={{fontFamily:"var(--font-mono)", fontSize:9.5, letterSpacing:"0.08em", color:"var(--color-text-faint)"}}>BOARD CARD · LIVE</span>
      </div>
      <div style={{fontSize:13.5, fontWeight:600}}>Order seed stock for spring beds</div>
      <div style={{display:"flex", alignItems:"center", gap:8, marginTop:8}}>
        <HmBadge tone="neutral" style={{fontSize:10.5, padding:"2px 7px"}}>Planned</HmBadge>
        <HmAvatar name="Priya Nair" size={18} />
        <span style={{fontSize:11, color:"var(--color-text-muted)", display:"inline-flex", alignItems:"center", gap:4}}><HmIcon name="calendar" size={11} />Mar 4</span>
      </div>
    </div>
    {/* selection actions */}
    <div style={{position:"absolute", left:300, top:56}}>
      <HmLiquidBar style={{padding:"5px 8px", gap:2}}>
        <HmLiquidIconButton label="Style" size={30}><HmIcon name="palette" size={14} /></HmLiquidIconButton>
        <HmLiquidIconButton label="Comment" size={30}><HmIcon name="message-circle" size={14} /></HmLiquidIconButton>
        <HmLiquidIconButton label="Copy" size={30}><HmIcon name="copy" size={14} /></HmLiquidIconButton>
      </HmLiquidBar>
    </div>
    {/* creation toolbar */}
    <div style={{position:"absolute", left:14, top:"50%", transform:"translateY(-50%)"}}>
      <HmLiquidBar style={{flexDirection:"column", padding:"10px 7px", gap:2}}>
        {tools.map(([id, icon]) => <HmLiquidIconButton key={id} label={id} active={tool === id} onClick={() => setTool(id)}><HmIcon name={icon} size={16} /></HmLiquidIconButton>)}
      </HmLiquidBar>
    </div>
    {/* zoom + minimap */}
    <div style={{position:"absolute", right:16, bottom:16, display:"flex", flexDirection:"column", gap:10, alignItems:"flex-end"}}>
      <HmLiquidSurface level="panel" radius={14} sheen={false} style={{width:150, height:96, padding:6, boxSizing:"border-box"}}>
        <div style={{position:"relative", width:"100%", height:"100%", borderRadius:8, background:"rgba(13,18,17,0.4)", overflow:"hidden"}}>
          <div style={{position:"absolute", left:"8%", top:"14%", width:"38%", height:"56%", borderRadius:2, border:"1px solid var(--color-border-strong)"}} />
          <div style={{position:"absolute", left:"58%", top:"26%", width:"22%", height:"18%", borderRadius:2, background:"rgba(15,191,174,0.35)"}} />
          <div style={{position:"absolute", left:"4%", top:"6%", width:"52%", height:"74%", border:"1.5px solid var(--color-accent)", borderRadius:3 }} />
        </div>
      </HmLiquidSurface>
      <HmLiquidBar style={{padding:"5px 8px"}}>
        <HmLiquidIconButton label="Zoom out" size={30}><HmIcon name="minus" size={14} /></HmLiquidIconButton>
        <span style={{fontFamily:"var(--font-mono)", fontSize:11.5, color:"var(--color-text)", padding:"0 4px"}}>82%</span>
        <HmLiquidIconButton label="Zoom in" size={30}><HmIcon name="plus" size={14} /></HmLiquidIconButton>
        <HmSeparator dot />
        <HmLiquidIconButton label="Fit to content" size={30}><HmIcon name="maximize" size={14} /></HmLiquidIconButton>
      </HmLiquidBar>
    </div>
    {/* inspector */}
    <div style={{position:"absolute", right:16, top:16}}>
      <HmLiquidSurface level="panel" cornerModule style={{width:210, padding:"16px 16px 18px", display:"flex", flexDirection:"column", gap:12}}>
        <div style={{fontFamily:"var(--font-mono)", fontSize:10, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)"}}>Sticky note</div>
        <div>
          <div style={{fontSize:12, fontWeight:600, marginBottom:7}}>Fill</div>
          <div style={{display:"flex", gap:7}}>
            {["#B8DED2","#EFE3B8","#D8C9EE","#EDC1B7","#FFFFFF"].map((c, i) => <span key={i} style={{width:22, height:22, borderRadius:8, background:c, border: i === 0 ? "2px solid var(--color-accent)" : "1px solid var(--color-border-strong)", cursor:"pointer"}} />)}
          </div>
        </div>
        <HmSlider label="Opacity" value={100} unit="%" />
      </HmLiquidSurface>
    </div>
  </div>;
};