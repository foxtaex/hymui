window.HmKit = window.HmKit || {};
window.HmKit.ProjectsHome = function ProjectsHome({ K, go }) {
  const { HmProgress, HmAvatar, HmBadge, HmButton, HmIcon, HmSearchInput, HmSeparator } = K;
  const projects = [
    { name: "Riverside Community Garden", desc: "Spring planting, volunteers, plot map", done: 62, members: ["Mara Ellis", "Jon Ade", "Priya Nair"], items: "2 boards · 5 docs · 1 whiteboard", tone: null },
    { name: "hymui core · 1.5 release", desc: "Federation handshake, plugin manifest, sync", done: 41, members: ["Jon Ade", "Sam Ortiz"], items: "3 boards · 12 docs", repo: "git · hymui/core", tone: "accent", badge: "agent running" },
    { name: "Autumn Exhibition", desc: "Venue, catalogue, artist outreach", done: 88, members: ["Priya Nair"], items: "1 board · 7 docs · 2 whiteboards", tone: null },
    { name: "Home renovation", desc: "Kitchen phase — quotes and permits", done: 15, members: ["Mara Ellis"], items: "1 board · 3 docs", tone: null }
  ];
  return <div style={{height:"100%", overflowY:"auto", padding:"28px 40px 40px", boxSizing:"border-box"}}>
    <div style={{maxWidth:1160, margin:"0 auto", display:"flex", flexDirection:"column", gap:22}}>
      <div style={{display:"flex", alignItems:"flex-end", justifyContent:"space-between", gap:20}}>
        <div>
          <div style={{fontFamily:"var(--font-mono)", fontSize:11, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)", marginBottom:6}}>Local instance · studio-north · 7 peers</div>
          <h1 style={{margin:0, fontSize:"var(--text-page-title-size)", fontWeight:600, letterSpacing:"-0.02em"}}>Projects</h1>
        </div>
        <div style={{display:"flex", gap:12, alignItems:"center"}}>
          <div style={{width:260}}><HmSearchInput placeholder="Search projects…" /></div>
          <HmButton iconLeft={<HmIcon name="plus" size={15} />}>New project</HmButton>
        </div>
      </div>
      <div style={{display:"flex", alignItems:"center", gap:10, padding:"10px 16px", borderRadius:"var(--radius-lg)", background:"var(--color-surface)", border:"1px solid var(--color-border)", cursor:"pointer"}}>
        <HmIcon name="folder" size={16} style={{color:"var(--hm-mint-subtle)"}} />
        <span style={{fontSize:14, fontWeight:600}}>Archive 2026</span>
        <span style={{fontSize:12.5, color:"var(--color-text-faint)"}}>4 projects</span>
        <span style={{marginLeft:"auto"}}><HmIcon name="chevron-right" size={15} style={{color:"var(--color-text-faint)"}} /></span>
      </div>
      <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(340px, 1fr))", gap:16}}>
        {projects.map((p, i) => <div key={i} onClick={() => go && go("board")} style={{
          background:"var(--color-surface)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-2xl)",
          padding:"22px 24px", display:"flex", flexDirection:"column", gap:14, cursor:"pointer",
          transition:"border-color var(--motion-fast) var(--ease-out), transform var(--motion-fast) var(--ease-out)"}}
          onMouseEnter={e => { e.currentTarget.style.borderColor = "rgba(15,191,174,0.35)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--color-border)"; e.currentTarget.style.transform = "none"; }}>
          <div style={{display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:12}}>
            <div>
              <div style={{fontSize:"var(--text-card-title-size)", fontWeight:600}}>{p.name}</div>
              <div style={{fontSize:13, color:"var(--color-text-muted)", marginTop:3}}>{p.desc}</div>
            </div>
            {p.badge && <HmBadge tone="accent" mono>{p.badge}</HmBadge>}
          </div>
          <HmProgress value={p.done} label="Progress" />
          <div style={{display:"flex", alignItems:"center", gap:8}}>
            <div style={{display:"flex"}}>{p.members.map((m, j) => <span key={j} style={{marginLeft: j ? -8 : 0}}><HmAvatar name={m} size={26} /></span>)}</div>
            <HmSeparator dot />
            <span style={{fontFamily:"var(--font-mono)", fontSize:10.5, color:"var(--color-text-faint)"}}>{p.items}</span>
            {p.repo && <><HmSeparator dot /><span style={{fontFamily:"var(--font-mono)", fontSize:10.5, color:"var(--hm-mint-subtle)"}}>{p.repo}</span></>}
          </div>
        </div>)}
      </div>
    </div>
  </div>;
};