window.HmKit = window.HmKit || {};
window.HmKit.PlannerView = function PlannerView({ K }) {
  const { HmLiquidControlGroup, HmBadge, HmAvatar, HmIcon, HmSeparator, HmButton } = K;
  const [view, setView] = React.useState("agenda");
  const items = [
    { day: "Thu · Feb 26", rows: [
      { time: "18:00", tz: "CET", t: "Compost workshop planning check-in", type: "Event", tone: "accent", proj: "Riverside Garden", src: "Planner" },
      { time: "all day", tz: "", t: "Irrigation quote comparison due", type: "Board card", tone: "neutral", proj: "Riverside Garden", src: "Board · Spring planting", who: "Sam Ortiz" }] },
    { day: "Sat · Feb 28", rows: [
      { time: "10:00", tz: "CET", t: "Volunteer day — bed preparation", type: "Event", tone: "accent", proj: "Riverside Garden", src: "Planner", who: "Mara Ellis" }] },
    { day: "Mon · Mar 2", rows: [
      { time: "", tz: "", t: "Federation handshake spec — freeze", type: "Milestone", tone: "success", proj: "hymui core · 1.5", src: "Project" },
      { time: "09:30", tz: "CET", t: "Grant application submission", type: "Board card", tone: "warning", proj: "Riverside Garden", src: "Board · Spring planting", who: "Priya Nair" }] }
  ];
  const days = ["M","T","W","T","F","S","S"];
  return <div style={{height:"100%", display:"flex", gap:20, padding:"10px 28px 24px", boxSizing:"border-box"}}>
    <div style={{flex:1, minWidth:0, display:"flex", flexDirection:"column", gap:16}}>
      <div style={{display:"flex", alignItems:"center", justifyContent:"space-between", gap:14}}>
        <div style={{fontSize:19, fontWeight:600}}>Planner <span style={{color:"var(--color-text-faint)", fontWeight:500}}>· February 2026</span></div>
        <HmLiquidControlGroup items={[{value:"agenda",label:"Agenda"},{value:"week",label:"Week"},{value:"month",label:"Month"},{value:"timeline",label:"Timeline"}]} value={view} onChange={setView} />
      </div>
      <div style={{flex:1, overflowY:"auto", display:"flex", flexDirection:"column", gap:20}}>
        {items.map((g, i) => <div key={i} style={{display:"flex", flexDirection:"column", gap:8}}>
          <div style={{fontFamily:"var(--font-mono)", fontSize:10.5, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)"}}>{g.day}</div>
          {g.rows.map((r, j) => <div key={j} style={{display:"flex", alignItems:"center", gap:14, background:"var(--color-surface)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-lg)", padding:"13px 18px", cursor:"pointer"}}>
            <div style={{width:64, flex:"none"}}>
              <div style={{fontFamily:"var(--font-mono)", fontSize:12.5, color:"var(--color-text)"}}>{r.time || "—"}</div>
              {r.tz && <div style={{fontFamily:"var(--font-mono)", fontSize:9.5, color:"var(--color-text-faint)"}}>{r.tz}</div>}
            </div>
            <HmSeparator vertical length={30} />
            <div style={{flex:1, minWidth:0}}>
              <div style={{fontSize:14, fontWeight:600, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}}>{r.t}</div>
              <div style={{display:"flex", alignItems:"center", gap:8, marginTop:4}}>
                <span style={{fontSize:11.5, color:"var(--color-text-muted)"}}>{r.proj}</span>
                <HmSeparator dot />
                <span style={{fontFamily:"var(--font-mono)", fontSize:10, color:"var(--color-text-faint)", display:"inline-flex", alignItems:"center", gap:5}}>{r.src}<HmIcon name="arrow-up-right" size={11} /></span>
              </div>
            </div>
            <HmBadge tone={r.tone} mono>{r.type}</HmBadge>
            {r.who && <HmAvatar name={r.who} size={24} />}
          </div>)}
        </div>)}
      </div>
    </div>
    <div style={{width:280, flex:"none", display:"flex", flexDirection:"column", gap:14}}>
      <div style={{background:"var(--color-surface)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-2xl)", padding:"18px 20px"}}>
        <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12}}>
          <span style={{fontSize:14, fontWeight:600}}>February</span>
          <span style={{fontFamily:"var(--font-mono)", fontSize:10, color:"var(--color-text-faint)"}}>2026</span>
        </div>
        <div style={{display:"grid", gridTemplateColumns:"repeat(7, 1fr)", gap:3, textAlign:"center"}}>
          {days.map((d, i) => <div key={"h"+i} style={{fontFamily:"var(--font-mono)", fontSize:9.5, color:"var(--color-text-faint)", padding:"3px 0"}}>{d}</div>)}
          {Array.from({length:28}, (_, i) => { const d = i + 1; const busy = [26, 28].includes(d); const today = d === 26;
            return <div key={d} style={{fontSize:11.5, padding:"5px 0", borderRadius:8, position:"relative",
              background: today ? "var(--hm-accent-gradient)" : "transparent",
              color: today ? "var(--color-on-accent)" : "var(--color-text-muted)", fontWeight: today ? 700 : 500}}>
              {d}{busy && !today && <span style={{position:"absolute", bottom:1, left:"50%", transform:"translateX(-50%)", width:3, height:3, borderRadius:"50%", background:"var(--color-accent)"}} />}
            </div>; })}
        </div>
      </div>
      <div style={{background:"var(--color-surface)", border:"1px solid var(--color-border)", borderRadius:"var(--radius-2xl)", padding:"18px 20px", display:"flex", flexDirection:"column", gap:10}}>
        <div style={{fontFamily:"var(--font-mono)", fontSize:10, letterSpacing:"0.12em", textTransform:"uppercase", color:"var(--color-text-faint)"}}>Sources</div>
        {[["Events", "accent"], ["Board cards", "neutral"], ["Milestones", "success"], ["Projects", "warning"]].map(([l, t], i) => <label key={i} style={{display:"flex", alignItems:"center", gap:9, fontSize:13.5, cursor:"pointer"}}>
          <span style={{width:10, height:10, borderRadius:4, background:`var(--color-${t === "neutral" ? "text-faint" : t})`, opacity:0.8}} />{l}
        </label>)}
      </div>
      <HmButton variant="secondary" iconLeft={<HmIcon name="plus" size={14} />}>New event</HmButton>
    </div>
  </div>;
};